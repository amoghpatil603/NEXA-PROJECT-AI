import { knowledgeEngine } from '../src/rag';
import { executionEngine, EngineState } from '../src/execution';
import { plannerEngine } from '../src/planner';
import { router } from '../src/router';
import { connector } from '../src/connector';
import * as fs from 'fs/promises';

async function runTest() {
    console.log("=== RAG Integration Tests ===");

    // 1. Create a dummy file
    await fs.writeFile('dummy_rag.txt', 'The NEXA system architecture relies on an advanced Knowledge Engine for retrieval augmented generation (RAG).\n\nThe Assistant Core orchestrates this process.', 'utf-8');

    // 2. Add to Knowledge Engine
    console.log("\n--- Adding Document ---");
    const docId = await knowledgeEngine.addDocument('dummy_rag.txt');
    console.log(`Document added with ID: ${docId}`);
    console.log(`Stats:`, knowledgeEngine.getStats());

    // 3. Direct Query
    console.log("\n--- Direct Query ---");
    const results = await knowledgeEngine.query("NEXA architecture", 2);
    console.log(`Retrieved ${results.length} results.`);
    results.forEach(r => console.log(` - Score: ${r.score.toFixed(4)} | Text: ${r.chunk.text}`));

    // 4. Test execution engine integration
    console.log("\n--- Execution Engine Integration ---");
    const plan = await plannerEngine.generatePlan("search for NEXA architecture details");
    await executionEngine.executePlan(plan);
    const history = executionEngine.getExecutionHistory();
    history.forEach(item => {
        console.log(`Task [${item.taskId}]: ${item.output?.status}`);
        if (item.output?.isRag) {
            console.log(`  RAG Outputs: ${item.output?.data?.length} chunks retrieved`);
        }
    });

    // 5. Test Router Integration
    console.log("\n--- Router Integration ---");
    // Mock the connector so we can see the system prompt
    connector.generate = async (req: any) => {
        console.log(`[Connector Mock] System Prompt length: ${req.system_prompt.length}`);
        console.log(req.system_prompt);
        return {
            response: "This is a mock AI response.",
            tokens_generated: 10,
            time_taken: 100,
            tokens_per_sec: 100
        };
    };

    const finalRes = await router.routeRequest({ message: "Search for the NEXA architecture" });
    console.log(`\nFinal output from router: ${finalRes}`);

    // Cleanup
    await fs.unlink('dummy_rag.txt');
    console.log("\n=== RAG Tests Complete ===");
}

runTest().catch(console.error);
