import { router } from '../src/router';
import { connector } from '../src/connector';
import { plannerEngine } from '../src/planner';
import { executionEngine } from '../src/execution';
import { toolEngine } from '../src/tools';

async function verify() {
    console.log("=== Starting End-to-End Verification ===");
    
    // We mock the connector to bypass actual fetch calls to AI model since we want to verify the local architectural pipeline
    connector.generate = async (req: any) => {
        console.log(`[Connector Mock] Processing request:\n`, req.system_prompt);
        return {
            response: "The result of your calculation is " + JSON.stringify(req),
            tokens_generated: 10,
            time_taken: 100,
            tokens_per_sec: 100
        };
    };

    const requests = [
        "Calculate 10 - 3 * 2",
        "Calculate 10 / 0",
        "Calculate (10 - 3) * 2",
        "Calculate 2 ^ 3 ^ 2",
        "Calculate 10 + "
    ];

    for (const req of requests) {
        console.log(`\n\n--- Testing Request: "${req}" ---`);
        const result = await router.routeRequest({ message: req });
        console.log(`\n[Final Output]:\n${result}`);
    }

    console.log("\n=== End-to-End Verification Complete ===");
}

verify().catch(console.error);
