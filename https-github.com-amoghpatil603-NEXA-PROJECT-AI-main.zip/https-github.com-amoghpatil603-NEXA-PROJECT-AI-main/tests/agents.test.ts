import { agentsEngine, agentManager } from '../src/agents';
import { executionEngine } from '../src/execution';
import { plannerEngine } from '../src/planner';
import { router } from '../src/router';
import { connector } from '../src/connector';

async function runTest() {
    console.log("=== Agent Framework Integration Tests ===");

    // 1. Direct Agent Operations
    console.log("\n--- Direct Agent Operations ---");
    const agents = agentsEngine.listAgents();
    console.log(`Registered Agents:`, agents.map(a => a.name).join(', '));
    
    const codingAgent = agentsEngine.getAgent('agent-coding');
    if (codingAgent) {
        console.log(`Executing Coding Agent directly...`);
        const res = await codingAgent.execute({ id: 'test-1', objective: 'Write a hello world function' });
        console.log(`Coding Agent Result Success:`, res.success);
        if (!res.success) {
            console.log(`Coding Agent Error:`, res.error);
        }
    }

    // 2. Test Execution Engine Integration
    console.log("\n--- Execution Engine Integration ---");
    const plan = await plannerEngine.generatePlan("Research the history of AI");
    await executionEngine.executePlan(plan);
    const history = executionEngine.getExecutionHistory();
    history.forEach(item => {
        console.log(`Task [${item.taskId}]: ${item.output?.status}`);
        if (item.output?.isAgent) {
            console.log(`  Agent Output:`, item.output?.data?.success ? 'Success' : 'Failure');
        }
    });

    // 3. Test Router Integration
    console.log("\n--- Router Integration ---");
    // Mock the connector
    connector.generate = async (req: any) => {
        console.log(`[Connector Mock] System Prompt length: ${req.system_prompt.length}`);
        if (req.system_prompt.includes('[Agent Framework Context]')) {
            console.log(`  Agent Context detected in final prompt!`);
        }
        return {
            response: "Agents are on the case.",
            tokens_generated: 10,
            time_taken: 100,
            tokens_per_sec: 100
        };
    };

    const finalRes = await router.routeRequest({ message: "code a simple react app" });
    console.log(`\nFinal output from router: ${finalRes}`);

    console.log("\n=== Agent Tests Complete ===");
}

runTest().catch(console.error);
