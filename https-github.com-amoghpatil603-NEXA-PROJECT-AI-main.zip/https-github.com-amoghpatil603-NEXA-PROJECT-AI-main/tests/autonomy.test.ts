import { autonomyManager } from '../src/autonomy';
import { GoalStatus } from '../src/autonomy/types';

async function testAutonomy() {
    console.log("=== Testing Autonomy Layer ===");
    
    // Test Goal Creation
    const goalId = await autonomyManager.startGoal("Build a simple calculator app");
    console.log(`[Test] Goal created: ${goalId}`);
    
    // Test Goal Status
    const status = autonomyManager.getGoalStatus(goalId);
    console.log(`[Test] Goal status: ${status}`);
    
    if (status === GoalStatus.IN_PROGRESS) {
        console.log("[Test] PASSED");
    } else {
        console.log("[Test] FAILED");
    }
}

testAutonomy().catch(console.error);
