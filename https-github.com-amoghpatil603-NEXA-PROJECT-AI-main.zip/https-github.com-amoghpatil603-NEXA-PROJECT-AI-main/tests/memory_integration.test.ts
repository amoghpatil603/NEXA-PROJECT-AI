import { memoryEngine, MemoryCategory } from "../src/memory";
import { ProductionContextEngine } from "../src/ai/context_engine";

async function runTests() {
    console.log("--- Testing Memory Integration ---");
    
    // Test 1: Add memory
    console.log("Testing: addMemory");
    const memId = await memoryEngine.addMemory("Hello world, I am testing.", MemoryCategory.LONG_TERM);
    console.log("Result: ", memId > 0 ? "PASSED" : "FAILED");

    // Test 2: Search memory
    console.log("Testing: retrieveContext");
    const context = await memoryEngine.retrieveContext("testing");
    console.log("Result: ", context.relevantMemories.length > 0 ? "PASSED" : "FAILED");

    // Test 3: ContextEngine integration
    console.log("Testing: ContextEngine.buildPrompt");
    const engine = new ProductionContextEngine();
    const promptObj = await engine.buildPrompt("I am testing.");
    console.log("Result: ", promptObj.prompt.includes("Hello world") ? "PASSED" : "FAILED");

    console.log("--- Integration Tests Finished ---");
}

runTests().catch(console.error);
