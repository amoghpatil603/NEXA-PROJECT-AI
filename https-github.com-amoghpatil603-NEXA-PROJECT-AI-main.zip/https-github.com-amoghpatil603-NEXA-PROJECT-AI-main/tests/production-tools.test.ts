import { executionEngine, EngineState } from '../src/execution';
import { toolEngine } from '../src/tools';
import { ExecutionPlan, TaskStatus, PlanType, PlanStatus } from '../src/planner';

async function runTest() {
    console.log("=== Production Tools Integration Test ===");

    // We will simulate a plan that invokes all the tools through the ExecutionEngine

    const plan: ExecutionPlan = {
        id: `plan-integration-${Date.now()}`,
        goal: "Test all production tools",
        type: PlanType.MULTI_STEP,
        status: PlanStatus.CREATED,
        tasks: [
            {
                id: "task-fs",
                description: "Write and read a file",
                requiredSubsystem: "TOOL_ENGINE",
                dependencies: [],
                status: TaskStatus.PENDING,
                toolId: "tool-filesystem",
                toolInput: { action: "write_file", path: "integration_test.txt", content: "FS Integration Data" }
            } as any,
            {
                id: "task-python",
                description: "Run python",
                requiredSubsystem: "TOOL_ENGINE",
                dependencies: ["task-fs"],
                status: TaskStatus.PENDING,
                toolId: "tool-python",
                toolInput: { code: "print('Python Execution Engine Integration')" }
            } as any,
            {
                id: "task-terminal",
                description: "Run terminal",
                requiredSubsystem: "TOOL_ENGINE",
                dependencies: ["task-python"],
                status: TaskStatus.PENDING,
                toolId: "tool-terminal",
                toolInput: { command: "echo 'Terminal Exec Engine'" }
            } as any,
            {
                id: "task-browser",
                description: "Run browser",
                requiredSubsystem: "TOOL_ENGINE",
                dependencies: ["task-terminal"],
                status: TaskStatus.PENDING,
                toolId: "tool-browser",
                toolInput: { url: "https://example.com" }
            } as any,
            {
                id: "task-pdf",
                description: "Run pdf (dummy)",
                requiredSubsystem: "TOOL_ENGINE",
                dependencies: ["task-browser"],
                status: TaskStatus.PENDING,
                toolId: "tool-pdf",
                toolInput: { path: "dummy.pdf" }
            } as any,
            {
                id: "task-ocr",
                description: "Run ocr (dummy)",
                requiredSubsystem: "TOOL_ENGINE",
                dependencies: ["task-pdf"],
                status: TaskStatus.PENDING,
                toolId: "tool-ocr",
                toolInput: { imagePath: "dummy.png" }
            } as any
        ]
    };

    console.log("\nStarting Execution Engine...");
    await executionEngine.executePlan(plan);

    console.log("\n--- Execution History ---");
    const history = executionEngine.getExecutionHistory();
    history.forEach(item => {
        console.log(`Task [${item.taskId}]: ${item.output?.status} (Time: ${item.output?.executionTimeMs}ms)`);
        if (item.output?.status === 'ERROR') {
            console.log(`  Error: ${item.output.error}`);
        } else if (item.taskId === 'task-terminal' || item.taskId === 'task-python') {
            console.log(`  Output: ${item.output?.data?.stdout?.trim()}`);
        }
    });

    console.log("\n=== Integration Test Complete ===");
}

runTest().catch(console.error);
