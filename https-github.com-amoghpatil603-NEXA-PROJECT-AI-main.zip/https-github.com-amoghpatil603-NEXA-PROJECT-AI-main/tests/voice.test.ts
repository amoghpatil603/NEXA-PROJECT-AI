import { voiceEngine } from '../src/voice';
import { executionEngine, EngineState } from '../src/execution';
import { plannerEngine } from '../src/planner';
import { router } from '../src/router';
import { connector } from '../src/connector';
import * as fs from 'fs/promises';

async function runTest() {
    console.log("=== Voice Subsystem Integration Tests ===");

    // 1. Direct Voice Analysis
    console.log("\n--- Direct Voice Operations ---");
    const listenResult = await voiceEngine.listen();
    console.log(`Listen Result:`, listenResult.text);
    
    await voiceEngine.speak("Hello, this is a test.");
    console.log(`Speak History:`, voiceEngine.getHistory());

    // 2. Test Execution Engine Integration
    console.log("\n--- Execution Engine Integration ---");
    const plan = await plannerEngine.generatePlan("Start voice chat");
    await executionEngine.executePlan(plan);
    const history = executionEngine.getExecutionHistory();
    history.forEach(item => {
        console.log(`Task [${item.taskId}]: ${item.output?.status}`);
        if (item.output?.isVoice) {
            console.log(`  Voice Output: ${JSON.stringify(item.output?.data)}`);
        }
    });

    // 3. Test Router Integration
    console.log("\n--- Router Integration ---");
    // Mock the connector
    connector.generate = async (req: any) => {
        console.log(`[Connector Mock] System Prompt length: ${req.system_prompt.length}`);
        if (req.system_prompt.includes('[Voice Context]')) {
            console.log(`  Voice Context detected in final prompt!`);
        }
        return {
            response: "Voice interface activated.",
            tokens_generated: 10,
            time_taken: 100,
            tokens_per_sec: 100
        };
    };

    const finalRes = await router.routeRequest({ message: "listen" });
    console.log(`\nFinal output from router: ${finalRes}`);

    console.log("\n=== Voice Tests Complete ===");
}

runTest().catch(console.error);
