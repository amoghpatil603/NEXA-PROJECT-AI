import { visionEngine, screenshotEngine } from '../src/vision';
import { executionEngine, EngineState } from '../src/execution';
import { plannerEngine } from '../src/planner';
import { router } from '../src/router';
import { connector } from '../src/connector';
import * as fs from 'fs/promises';

async function runTest() {
    console.log("=== Vision Subsystem Integration Tests ===");

    // 1. Create a mock image file
    const mockImagePath = '/tmp/mock_image.png';
    const base64Png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACklEQVR4nGMAAQAABQABDQottAAAAABJRU5ErkJggg==";
    await fs.writeFile(mockImagePath, Buffer.from(base64Png, 'base64'));

    // 2. Direct Image Analysis
    console.log("\n--- Direct Image Analysis ---");
    const analysis = await visionEngine.analyze(mockImagePath, { resize: { width: 800, height: 600 } });
    console.log(`Image Metadata:`, analysis.imageMetadata);
    console.log(`Caption:`, analysis.caption.text);
    console.log(`Objects Detected:`, analysis.objects.length);
    console.log(`UI Summary:`, analysis.ui.summary);

    // 3. Screenshot Capture
    console.log("\n--- Screenshot Engine ---");
    const screenshot = await screenshotEngine.capture();
    console.log(`Screenshot Captured: ${screenshot.path} (Format: ${screenshot.format})`);

    // 4. Test Execution Engine Integration
    console.log("\n--- Execution Engine Integration ---");
    const plan = await plannerEngine.generatePlan("Analyze this UI screenshot");
    await executionEngine.executePlan(plan);
    const history = executionEngine.getExecutionHistory();
    history.forEach(item => {
        console.log(`Task [${item.taskId}]: ${item.output?.status}`);
        if (item.output?.isVision) {
            console.log(`  Vision Output Elements: ${item.output?.data?.ui?.elements?.length}`);
        }
    });

    // 5. Test Router Integration
    console.log("\n--- Router Integration ---");
    // Mock the connector
    connector.generate = async (req: any) => {
        console.log(`[Connector Mock] System Prompt length: ${req.system_prompt.length}`);
        if (req.system_prompt.includes('[Vision Analysis]')) {
            console.log(`  Vision Context detected in final prompt!`);
        }
        return {
            response: "I see buttons and forms on your screen.",
            tokens_generated: 15,
            time_taken: 100,
            tokens_per_sec: 150
        };
    };

    const finalRes = await router.routeRequest({ message: "What is on my screen right now?" });
    console.log(`\nFinal output from router: ${finalRes}`);

    // Cleanup
    await fs.unlink(mockImagePath).catch(() => {});
    await fs.unlink(screenshot.path).catch(() => {});
    console.log("\n=== Vision Tests Complete ===");
}

runTest().catch(console.error);
