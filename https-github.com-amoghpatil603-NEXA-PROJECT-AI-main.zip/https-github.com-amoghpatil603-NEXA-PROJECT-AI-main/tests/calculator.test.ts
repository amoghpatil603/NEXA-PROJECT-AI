import { CalculatorParser } from '../src/tools/calculator';

const tests = [
    { expr: "2 + 2", expected: 4 },
    { expr: "10 - 3 * 2", expected: 4 },
    { expr: "(10 - 3) * 2", expected: 14 },
    { expr: "10 / 2", expected: 5 },
    { expr: "10 / 0", error: "Divide by zero" },
    { expr: "-5 + 3", expected: -2 },
    { expr: "2 ^ 3", expected: 8 },
    { expr: "2 ** 3", expected: 8 },
    { expr: "2 ^ 3 ^ 2", expected: 512 },
    { expr: "10 % 3", expected: 1 },
    { expr: "3.5 * 2", expected: 7 },
    { expr: "-.5 * 2", expected: -1 },
    { expr: "10 + ", error: "Unexpected end of expression" },
    { expr: "10 + a", error: "Invalid character 'a' at index 5" },
    { expr: "(2 + 2", error: "Missing closing parenthesis" }, // missing closing paren
    { expr: "", error: "Empty expression" }
];

let passed = 0;
for (const t of tests) {
    try {
        const result = new CalculatorParser(t.expr).parse();
        if (t.error) {
            console.error(`FAILED: ${t.expr} - Expected error '${t.error}', got result ${result}`);
        } else if (result !== t.expected) {
            console.error(`FAILED: ${t.expr} - Expected ${t.expected}, got ${result}`);
        } else {
            passed++;
        }
    } catch (e: any) {
        if (!t.error) {
            console.error(`FAILED: ${t.expr} - Expected ${t.expected}, got error: ${e.message}`);
        } else if (e.message !== t.error) {
            console.error(`FAILED: ${t.expr} - Expected error '${t.error}', got '${e.message}'`);
        } else {
            passed++;
        }
    }
}
console.log(`Tests passed: ${passed}/${tests.length}`);
