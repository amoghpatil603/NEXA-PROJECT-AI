import { desktopEngine } from '../src/desktop';
import { executionEngine } from '../src/execution';
import { plannerEngine } from '../src/planner';
import { router } from '../src/router';
import { connector } from '../src/connector';

async function runTest() {
    console.log("=== Desktop Subsystem Integration Tests ===");

    // 1. Direct Desktop Operations
    console.log("\n--- Direct Desktop Operations ---");
    const windows = await desktopEngine.execute({ type: 'window', action: 'list' });
    console.log(`Windows:`, windows.length);
    
    const pos = await desktopEngine.execute({ type: 'mouse', action: 'position' });
    console.log(`Mouse Position:`, pos);

    // 2. Test Execution Engine Integration
    console.log("\n--- Execution Engine Integration ---");
    const plan = await plannerEngine.generatePlan("Take a screenshot and list windows");
    await executionEngine.executePlan(plan);
    const history = executionEngine.getExecutionHistory();
    history.forEach(item => {
        console.log(`Task [${item.taskId}]: ${item.output?.status}`);
        if (item.output?.isDesktop) {
            console.log(`  Desktop Output Type: ${typeof item.output?.data}`);
        }
    });

    // 3. Test Router Integration
    console.log("\n--- Router Integration ---");
    // Mock the connector
    connector.generate = async (req: any) => {
        console.log(`[Connector Mock] System Prompt length: ${req.system_prompt.length}`);
        if (req.system_prompt.includes('[Desktop Context]')) {
            console.log(`  Desktop Context detected in final prompt!`);
        }
        return {
            response: "I see your desktop windows.",
            tokens_generated: 10,
            time_taken: 100,
            tokens_per_sec: 100
        };
    };

    const finalRes = await router.routeRequest({ message: "list my windows" });
    console.log(`\nFinal output from router: ${finalRes}`);

    // 4. Test Permissions
    console.log("\n--- Permission System ---");
    const logs = desktopEngine.security.getAuditLogs();
    console.log(`Audit Logs count: ${logs.length}`);
    
    console.log("\n=== Desktop Tests Complete ===");
}

runTest().catch(console.error);
