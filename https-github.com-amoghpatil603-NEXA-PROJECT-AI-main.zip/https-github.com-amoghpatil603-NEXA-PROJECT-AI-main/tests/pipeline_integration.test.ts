import { router } from "../src/router";
import { Subsystem } from "../src/types";

async function runTests() {
    console.log("--- Testing Pipeline Integration ---");
    
    // Test 1: Router path determination
    const message = "calculate 2 + 2";
    console.log(`Testing Router for: "${message}"`);
    const route = await router.determineRouting(message);
    console.log("Determined route: ", route);
    
    const hasMemory = route.includes(Subsystem.MEMORY);
    const hasPlanner = route.includes(Subsystem.PLANNER);
    
    console.log("Result: ", (hasMemory && hasPlanner) ? "PASSED" : "FAILED");

    // Test 2: Process subsystem
    console.log("Testing processSubsystem (Memory)");
    const memoryMessage = "Remember that my favorite language is Python.";
    const context: any = {
        originalMessage: memoryMessage,
        history: [],
        routingPath: route
    };
    await (router as any).processSubsystem(Subsystem.MEMORY, context);
    console.log("Memory context populated: ", !!context.memoryContext);
    console.log("Result: ", !!context.memoryContext ? "PASSED" : "FAILED");

    console.log("--- Integration Tests Finished ---");
}

runTests().catch(console.error);
