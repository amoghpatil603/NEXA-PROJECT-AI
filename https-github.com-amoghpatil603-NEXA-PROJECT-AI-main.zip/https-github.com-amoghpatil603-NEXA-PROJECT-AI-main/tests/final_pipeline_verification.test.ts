import { router } from "../src/router";
import { Subsystem } from "../src/types";

async function verifyScenario(label: string, message: string) {
    console.log(`\n--- Verification: ${label} ---`);
    console.log(`Message: "${message}"`);
    
    // Simulate server.ts request processing
    const route = await router.determineRouting(message);
    console.log("Actual execution path (Routing): ", route.join(' -> '));
    
    const context: any = {
        originalMessage: message,
        history: [],
        routingPath: route
    };
    
    // Process subsystems and log activity
    for (const subsystem of route) {
        await (router as any).processSubsystem(subsystem, context);
    }
    
    console.log("--- End Verification ---\n");
}

async function runTests() {
    await verifyScenario("Scenario 1: Hello", "Hello");
    await verifyScenario("Scenario 2: Remember Python", "Remember that my favorite language is Python.");
    await verifyScenario("Scenario 3: What is favorite", "What is my favorite language?");
    await verifyScenario("Scenario 4: Summarize README", "Summarize README.md");
    await verifyScenario("Scenario 5: Calculate", "Calculate 245 * 38");
    await verifyScenario("Scenario 6: Search Documents", "Search documents for transformer architecture");
}

runTests().catch(console.error);
