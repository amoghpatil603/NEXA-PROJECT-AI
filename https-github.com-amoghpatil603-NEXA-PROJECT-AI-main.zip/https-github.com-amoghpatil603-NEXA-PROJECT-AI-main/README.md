# NEXA

NEXA Local-First Conversational AI Assistant.

Migrated to AI Studio.
