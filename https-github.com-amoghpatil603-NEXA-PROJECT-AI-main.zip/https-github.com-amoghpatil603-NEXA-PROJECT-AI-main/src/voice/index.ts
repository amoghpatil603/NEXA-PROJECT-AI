import { AudioCaptureEngine } from './audio_capture';
import { AudioPlayer } from './audio_player';
import { MockSTTModel } from './speech_to_text';
import { MockTTSModel } from './text_to_speech';
import { MockWakeWordEngine } from './wake_word';
import { MockNoiseFilter } from './noise_filter';
import { VoiceSession } from './voice_session';

export * from './types';
export * from './audio_capture';
export * from './audio_player';
export * from './speech_to_text';
export * from './text_to_speech';
export * from './wake_word';
export * from './noise_filter';
export * from './voice_session';

const captureEngine = new AudioCaptureEngine();
const player = new AudioPlayer();
const stt = new MockSTTModel();
const tts = new MockTTSModel();
const wakeWord = new MockWakeWordEngine();
const noiseFilter = new MockNoiseFilter();

export const voiceEngine = new VoiceSession(
    captureEngine,
    player,
    stt,
    tts,
    wakeWord,
    noiseFilter
);
