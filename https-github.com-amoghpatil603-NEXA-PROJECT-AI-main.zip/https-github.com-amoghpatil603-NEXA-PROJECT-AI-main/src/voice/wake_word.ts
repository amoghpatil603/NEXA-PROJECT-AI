import { AudioBuffer } from './types';

export interface WakeWordEngine {
    detect(buffer: AudioBuffer): Promise<boolean>;
}

export class MockWakeWordEngine implements WakeWordEngine {
    constructor(private wakeWord: string = "Hey NEXA") {}

    async detect(buffer: AudioBuffer): Promise<boolean> {
        // Placeholder for local wake word detection model
        return false;
    }
}
