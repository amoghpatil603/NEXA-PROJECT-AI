import { AudioBuffer, TranscriptionResult } from './types';

export interface STTModel {
    transcribe(buffer: AudioBuffer): Promise<TranscriptionResult>;
    transcribeStream(stream: AsyncIterable<AudioBuffer>): AsyncIterable<TranscriptionResult>;
}

export class MockSTTModel implements STTModel {
    async transcribe(buffer: AudioBuffer): Promise<TranscriptionResult> {
        // Mock STT
        return {
            text: "This is a mock transcription with punctuation.",
            confidence: 0.98,
            language: "en",
            words: [
                { word: "This", startMs: 0, endMs: 100, confidence: 0.99 }
            ]
        };
    }

    async *transcribeStream(stream: AsyncIterable<AudioBuffer>): AsyncIterable<TranscriptionResult> {
        for await (const buffer of stream) {
            yield await this.transcribe(buffer);
        }
    }
}
