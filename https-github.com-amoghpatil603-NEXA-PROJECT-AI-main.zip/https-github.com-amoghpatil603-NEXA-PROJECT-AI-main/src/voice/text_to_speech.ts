import { AudioBuffer, TTSOptions } from './types';

export interface TTSModel {
    synthesize(text: string, options?: TTSOptions): Promise<AudioBuffer>;
    synthesizeStream(text: string, options?: TTSOptions): AsyncIterable<AudioBuffer>;
}

export class MockTTSModel implements TTSModel {
    async synthesize(text: string, options?: TTSOptions): Promise<AudioBuffer> {
        // Mock TTS
        return {
            data: new Float32Array(4096),
            sampleRate: 24000,
            channels: 1,
            format: 'pcm'
        };
    }

    async *synthesizeStream(text: string, options?: TTSOptions): AsyncIterable<AudioBuffer> {
        // Mock streaming TTS chunks
        yield await this.synthesize(text, options);
    }
}
