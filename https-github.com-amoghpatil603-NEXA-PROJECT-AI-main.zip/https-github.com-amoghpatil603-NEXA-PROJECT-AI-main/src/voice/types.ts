export interface AudioBuffer {
    data: Float32Array;
    sampleRate: number;
    channels: number;
    format: 'wav' | 'mp3' | 'flac' | 'ogg' | 'pcm';
}

export interface TranscriptionWord {
    word: string;
    startMs: number;
    endMs: number;
    confidence: number;
}

export interface TranscriptionResult {
    text: string;
    confidence: number;
    language?: string;
    words?: TranscriptionWord[];
}

export interface TTSOptions {
    voice?: string;
    speed?: number;
    pitch?: number;
    volume?: number;
}

export interface VoiceSessionState {
    isActive: boolean;
    isListening: boolean;
    isSpeaking: boolean;
}
