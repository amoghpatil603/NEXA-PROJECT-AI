import { AudioBuffer } from './types';

export interface NoiseFilter {
    suppressNoise(buffer: AudioBuffer): Promise<AudioBuffer>;
    detectSilence(buffer: AudioBuffer, threshold?: number): boolean;
}

export class MockNoiseFilter implements NoiseFilter {
    async suppressNoise(buffer: AudioBuffer): Promise<AudioBuffer> {
        // Mock noise suppression
        return buffer;
    }

    detectSilence(buffer: AudioBuffer, threshold: number = 0.01): boolean {
        // Mock silence detection
        let maxAmplitude = 0;
        for (let i = 0; i < buffer.data.length; i++) {
            if (Math.abs(buffer.data[i]) > maxAmplitude) {
                maxAmplitude = Math.abs(buffer.data[i]);
            }
        }
        return maxAmplitude < threshold;
    }
}
