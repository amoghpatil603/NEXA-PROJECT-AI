import { AudioCaptureEngine } from './audio_capture';
import { AudioPlayer } from './audio_player';
import { STTModel } from './speech_to_text';
import { TTSModel } from './text_to_speech';
import { WakeWordEngine } from './wake_word';
import { NoiseFilter } from './noise_filter';
import { VoiceSessionState, TTSOptions, TranscriptionResult } from './types';

export class VoiceSession {
    private state: VoiceSessionState = {
        isActive: false,
        isListening: false,
        isSpeaking: false
    };
    
    private history: { role: 'user' | 'assistant', text: string, timestamp: number }[] = [];

    constructor(
        private captureEngine: AudioCaptureEngine,
        private player: AudioPlayer,
        private stt: STTModel,
        private tts: TTSModel,
        private wakeWordEngine: WakeWordEngine,
        private noiseFilter: NoiseFilter
    ) {}

    async startSession(): Promise<void> {
        this.state.isActive = true;
    }

    async endSession(): Promise<void> {
        this.state.isActive = false;
        await this.stopListening();
        await this.stopSpeaking();
    }

    async listen(): Promise<TranscriptionResult> {
        this.state.isListening = true;
        // In reality, this would stream from captureEngine, apply noiseFilter, and wait for silence.
        const buffer = await this.captureEngine.captureStream(5000);
        const filtered = await this.noiseFilter.suppressNoise(buffer);
        const result = await this.stt.transcribe(filtered);
        
        this.history.push({ role: 'user', text: result.text, timestamp: Date.now() });
        this.state.isListening = false;
        return result;
    }

    async speak(text: string, options?: TTSOptions): Promise<void> {
        // Interrupt detection logic would go here
        await this.stopSpeaking(); 
        
        this.state.isSpeaking = true;
        const audio = await this.tts.synthesize(text, options);
        this.history.push({ role: 'assistant', text, timestamp: Date.now() });
        
        await this.player.play(audio);
        this.state.isSpeaking = false;
    }

    async interrupt(): Promise<void> {
        await this.stopSpeaking();
    }

    async pauseSpeech(): Promise<void> {
        await this.player.pause();
    }

    async resumeSpeech(): Promise<void> {
        await this.player.resume();
    }

    async stopSpeaking(): Promise<void> {
        await this.player.stop();
        this.state.isSpeaking = false;
    }

    async stopListening(): Promise<void> {
        await this.captureEngine.stopMicrophone();
        this.state.isListening = false;
    }
    
    getHistory() {
        return this.history;
    }
    
    getState() {
        return this.state;
    }
}
