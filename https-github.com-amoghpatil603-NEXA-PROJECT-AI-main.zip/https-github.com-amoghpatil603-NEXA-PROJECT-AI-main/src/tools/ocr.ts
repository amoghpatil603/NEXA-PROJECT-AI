import { createWorker } from 'tesseract.js';
import * as fs from 'fs/promises';
import { BaseTool, ToolCategory, ToolResult, ToolStatus } from './types';

export class OCRTool implements BaseTool {
    id = 'tool-ocr';
    name = 'OCR';
    description = 'Extracts text from images';
    category = ToolCategory.DOCUMENT;
    version = '1.0.0';

    private worker: Tesseract.Worker | null = null;
    private isCancelled = false;

    async validate(input: any): Promise<boolean> {
        return typeof input?.imagePath === 'string';
    }

    async execute(input: any): Promise<ToolResult> {
        const start = Date.now();
        this.isCancelled = false;
        
        try {
            // Check if file exists first
            await fs.stat(input.imagePath);

            this.worker = await createWorker('eng');
            
            if (this.isCancelled) throw new Error("Cancelled by user");

            const { data: { text, confidence, words } } = (await this.worker.recognize(input.imagePath)) as any;
            
            await this.worker.terminate();
            this.worker = null;

            if (this.isCancelled) throw new Error("Cancelled by user");

            return {
                status: ToolStatus.SUCCESS,
                data: {
                    text,
                    confidence,
                    words: words.map(w => ({ text: w.text, confidence: w.confidence, bbox: w.bbox }))
                },
                executionTimeMs: Date.now() - start
            };
        } catch (error: any) {
            if (this.worker) {
                await this.worker.terminate().catch(() => {});
                this.worker = null;
            }
            return {
                status: ToolStatus.ERROR,
                error: error.message,
                executionTimeMs: Date.now() - start
            };
        }
    }

    cancel(): void {
        this.isCancelled = true;
        if (this.worker) {
            this.worker.terminate().catch(() => {});
            this.worker = null;
        }
    }

    getCapabilities(): string[] { return ['image_to_text', 'ocr']; }
}
