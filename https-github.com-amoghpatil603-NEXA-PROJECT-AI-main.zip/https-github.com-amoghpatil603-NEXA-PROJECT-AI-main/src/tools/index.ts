import { Subsystem } from '../types';
import { CalculatorTool } from './calculator';
import { FilesystemTool } from './filesystem';
import { PythonTool } from './python';
import { TerminalTool } from './terminal';
import { BrowserTool } from './browser';
import { PDFTool } from './pdf';
import { OCRTool } from './ocr';
import { ToolCategory, ToolStatus, ToolResult, BaseTool } from './types';

export { CalculatorTool, FilesystemTool, PythonTool, TerminalTool, BrowserTool, PDFTool, OCRTool, ToolCategory, ToolStatus };
export type { ToolResult, BaseTool };

export class ToolRegistry {
    private tools: Map<string, BaseTool> = new Map();

    registerTool(tool: BaseTool): void {
        this.tools.set(tool.id, tool);
        console.log(`[ToolRegistry] Registered tool: ${tool.name} (${tool.id})`);
    }

    unregisterTool(toolId: string): void {
        this.tools.delete(toolId);
        console.log(`[ToolRegistry] Unregistered tool: ${toolId}`);
    }

    getTool(toolId: string): BaseTool | undefined {
        return this.tools.get(toolId);
    }

    listTools(): BaseTool[] {
        return Array.from(this.tools.values());
    }

    async executeTool(toolId: string, input: any): Promise<ToolResult> {
        const tool = this.getTool(toolId);
        if (!tool) {
            return {
                status: ToolStatus.ERROR,
                error: `Tool ${toolId} not found in registry.`,
                executionTimeMs: 0
            };
        }

        const start = Date.now();
        try {
            const isValid = await tool.validate(input);
            if (!isValid) {
                return {
                    status: ToolStatus.ERROR,
                    error: `Invalid input for tool ${toolId}.`,
                    executionTimeMs: Date.now() - start
                };
            }

            const result = await tool.execute(input);
            
            // Safety check in case the tool didn't properly compute time
            if (result.executionTimeMs === undefined) {
                 result.executionTimeMs = Date.now() - start;
            }
            
            return result;
        } catch (e: any) {
            return {
                status: ToolStatus.ERROR,
                error: e.message || `Execution failed for tool ${toolId}`,
                executionTimeMs: Date.now() - start
            };
        }
    }
}

// -----------------------------------------------------------------------------
// Singleton Engine Initialization
// -----------------------------------------------------------------------------

export const toolEngine = new ToolRegistry();

toolEngine.registerTool(new CalculatorTool());
toolEngine.registerTool(new FilesystemTool());
toolEngine.registerTool(new PythonTool());
toolEngine.registerTool(new TerminalTool());
toolEngine.registerTool(new BrowserTool());
toolEngine.registerTool(new PDFTool());
toolEngine.registerTool(new OCRTool());
