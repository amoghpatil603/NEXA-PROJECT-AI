import { BaseTool, ToolCategory, ToolResult, ToolStatus } from './types';

export class ExpressionError extends Error {
    constructor(message: string) {
        super(message);
        this.name = 'ExpressionError';
    }
}

export class CalculatorParser {
    private pos: number = 0;
    private readonly tokens: string[];

    constructor(expression: string) {
        this.tokens = this.tokenize(expression);
    }

    private tokenize(expr: string): string[] {
        const tokens: string[] = [];
        let i = 0;
        while (i < expr.length) {
            const char = expr[i];
            if (/\s/.test(char)) {
                i++;
                continue;
            }
            
            if (char === '*' && expr[i+1] === '*') {
                tokens.push('^');
                i += 2;
                continue;
            }

            if (/[+\-*/%^()]/.test(char)) {
                tokens.push(char);
                i++;
                continue;
            }
            
            if (/[0-9.]/.test(char)) {
                let numStr = '';
                let hasDot = false;
                while (i < expr.length && /[0-9.]/.test(expr[i])) {
                    if (expr[i] === '.') {
                        if (hasDot) throw new ExpressionError(`Invalid number format at index ${i}`);
                        hasDot = true;
                    }
                    numStr += expr[i];
                    i++;
                }
                if (numStr === '.') throw new ExpressionError(`Invalid number format at index ${i-1}`);
                tokens.push(numStr);
                continue;
            }
            
            throw new ExpressionError(`Invalid character '${char}' at index ${i}`);
        }
        return tokens;
    }

    private peek(): string | null {
        return this.pos < this.tokens.length ? this.tokens[this.pos] : null;
    }

    private consume(): string | null {
        return this.pos < this.tokens.length ? this.tokens[this.pos++] : null;
    }

    public parse(): number {
        if (this.tokens.length === 0) {
            throw new ExpressionError('Empty expression');
        }
        const result = this.parseExpression();
        if (this.pos < this.tokens.length) {
            throw new ExpressionError(`Unexpected token '${this.peek()}'`);
        }
        return result;
    }

    private parseExpression(): number {
        let left = this.parseTerm();
        while (true) {
            const token = this.peek();
            if (token === '+' || token === '-') {
                this.consume();
                const right = this.parseTerm();
                if (token === '+') left += right;
                else left -= right;
            } else {
                break;
            }
        }
        return left;
    }

    private parseTerm(): number {
        let left = this.parseFactor();
        while (true) {
            const token = this.peek();
            if (token === '*' || token === '/' || token === '%') {
                this.consume();
                const right = this.parseFactor();
                if (token === '*') left *= right;
                else if (token === '/') {
                    if (right === 0) throw new ExpressionError('Divide by zero');
                    left /= right;
                }
                else if (token === '%') left %= right;
            } else {
                break;
            }
        }
        return left;
    }

    private parseFactor(): number {
        let left = this.parsePower();
        const token = this.peek();
        if (token === '^') {
            this.consume();
            const right = this.parseFactor(); // right-associative recursion
            return Math.pow(left, right);
        }
        return left;
    }

    private parsePower(): number {
        const token = this.peek();
        if (token === null) throw new ExpressionError('Unexpected end of expression');
        
        if (token === '+') {
            this.consume();
            return this.parsePower();
        }
        if (token === '-') {
            this.consume();
            return -this.parsePower();
        }
        if (token === '(') {
            this.consume();
            const result = this.parseExpression();
            if (this.consume() !== ')') throw new ExpressionError('Missing closing parenthesis');
            return result;
        }
        
        // Number
        if (/[0-9]/.test(token[0]) || (token[0] === '.' && token.length > 1)) {
            this.consume();
            return parseFloat(token);
        }
        
        throw new ExpressionError(`Unexpected token '${token}'`);
    }
}

export class CalculatorTool implements BaseTool {
    id = 'tool-calculator';
    name = 'Calculator';
    description = 'Evaluates mathematical expressions safely';
    category = ToolCategory.UTILITY;
    version = '1.0.0';

    async validate(input: any): Promise<boolean> {
        return typeof input?.expression === 'string' && input.expression.trim().length > 0;
    }

    async execute(input: any): Promise<ToolResult> {
        const start = Date.now();
        try {
            const parser = new CalculatorParser(input.expression);
            const result = parser.parse();
            return {
                status: ToolStatus.SUCCESS,
                data: { result, expression: input.expression },
                executionTimeMs: Date.now() - start
            };
        } catch (error: any) {
            return {
                status: ToolStatus.ERROR,
                error: error.message,
                executionTimeMs: Date.now() - start
            };
        }
    }

    cancel(): void {}
    getCapabilities(): string[] { return ['math_evaluation']; }
}
