export enum ToolCategory {
    UTILITY = 'UTILITY',
    SYSTEM = 'SYSTEM',
    EXECUTION = 'EXECUTION',
    WEB = 'WEB',
    DOCUMENT = 'DOCUMENT'
}

export enum ToolStatus {
    SUCCESS = 'SUCCESS',
    ERROR = 'ERROR',
    CANCELLED = 'CANCELLED'
}

export interface ToolResult {
    status: ToolStatus;
    data?: any;
    error?: string;
    executionTimeMs: number;
}

export interface BaseTool {
    id: string;
    name: string;
    description: string;
    category: ToolCategory;
    version: string;

    validate(input: any): boolean | Promise<boolean>;
    execute(input: any): Promise<ToolResult>;
    cancel(): void;
    getCapabilities(): string[];
}
