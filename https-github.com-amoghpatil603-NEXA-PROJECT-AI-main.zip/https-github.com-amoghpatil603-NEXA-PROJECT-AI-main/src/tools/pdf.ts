import * as fs from 'fs/promises';
import * as pdfParseModule from 'pdf-parse';
const pdfParse = (pdfParseModule as any).default || pdfParseModule;
import { BaseTool, ToolCategory, ToolResult, ToolStatus } from './types';

export class PDFTool implements BaseTool {
    id = 'tool-pdf';
    name = 'PDF Reader';
    description = 'Extracts text and metadata from PDF files';
    category = ToolCategory.DOCUMENT;
    version = '1.0.0';

    async validate(input: any): Promise<boolean> {
        return typeof input?.path === 'string';
    }

    async execute(input: any): Promise<ToolResult> {
        const start = Date.now();
        try {
            const dataBuffer = await fs.readFile(input.path);
            
            // Custom render function for per-page extraction
            const pages: string[] = [];
            const render_page = async (pageData: any) => {
                const render_options = {
                    normalizeWhitespace: false,
                    disableCombineTextItems: false
                };
                const textContent = await pageData.getTextContent(render_options);
                let lastY, text = '';
                for (let item of textContent.items) {
                    if (lastY == item.transform[5] || !lastY) {
                        text += item.str;
                    } else {
                        text += '\n' + item.str;
                    }
                    lastY = item.transform[5];
                }
                pages.push(text);
                return text;
            };

            const options = {
                pagerender: render_page
            };

            const data = await pdfParse(dataBuffer, options);

            return {
                status: ToolStatus.SUCCESS,
                data: {
                    text: data.text,
                    pages: data.numpages,
                    metadata: data.info,
                    pageTexts: pages
                },
                executionTimeMs: Date.now() - start
            };
        } catch (error: any) {
            return {
                status: ToolStatus.ERROR,
                error: error.message,
                executionTimeMs: Date.now() - start
            };
        }
    }

    cancel(): void {}
    getCapabilities(): string[] { return ['pdf_parsing', 'text_extraction']; }
}
