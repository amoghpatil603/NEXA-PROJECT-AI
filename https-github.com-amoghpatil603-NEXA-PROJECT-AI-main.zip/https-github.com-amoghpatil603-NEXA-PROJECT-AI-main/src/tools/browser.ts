import { BaseTool, ToolCategory, ToolResult, ToolStatus } from './types';

export class BrowserTool implements BaseTool {
    id = 'tool-browser';
    name = 'Browser';
    description = 'Navigates and scrapes web pages';
    category = ToolCategory.WEB;
    version = '1.0.0';

    private abortController: AbortController | null = null;

    async validate(input: any): Promise<boolean> {
        return typeof input?.url === 'string';
    }

    private extractTextFromHtml(html: string): string {
        // Simple regex to extract text by removing scripts, styles, and tags
        let text = html;
        text = text.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, ' ');
        text = text.replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, ' ');
        text = text.replace(/<[^>]+>/g, ' ');
        // Replace multiple spaces with a single space
        text = text.replace(/\s+/g, ' ').trim();
        return text;
    }

    private extractTitle(html: string): string {
        const match = html.match(/<title[^>]*>([^<]+)<\/title>/i);
        return match ? match[1].trim() : '';
    }

    private extractLinks(html: string): string[] {
        const links: string[] = [];
        const regex = /<a\s+(?:[^>]*?\s+)?href=(["'])(.*?)\1/gi;
        let match;
        while ((match = regex.exec(html)) !== null) {
            if (match[2]) links.push(match[2]);
        }
        return [...new Set(links)]; // deduplicate
    }

    async execute(input: any): Promise<ToolResult> {
        const start = Date.now();
        const timeoutMs = input.timeout || 15000;
        this.abortController = new AbortController();
        const timeoutId = setTimeout(() => this.abortController?.abort(), timeoutMs);

        try {
            const method = input.method?.toUpperCase() || 'GET';
            const headers = input.headers || {};
            const body = input.body ? (typeof input.body === 'string' ? input.body : JSON.stringify(input.body)) : undefined;

            const response = await fetch(input.url, {
                method,
                headers,
                body,
                signal: this.abortController.signal
            });

            const contentType = response.headers.get('content-type') || '';
            const isJson = contentType.includes('application/json');
            
            const responseText = await response.text();
            clearTimeout(timeoutId);
            this.abortController = null;

            let parsedContent = {};
            if (isJson) {
                try { parsedContent = JSON.parse(responseText); } catch (_) {}
            } else if (contentType.includes('text/html')) {
                parsedContent = {
                    title: this.extractTitle(responseText),
                    text: this.extractTextFromHtml(responseText).substring(0, 10000), // truncate for sanity
                    links: this.extractLinks(responseText).slice(0, 100) // limit links
                };
            }

            return {
                status: ToolStatus.SUCCESS,
                data: {
                    url: input.url,
                    statusCode: response.status,
                    headers: Object.fromEntries(response.headers.entries()),
                    content: isJson ? parsedContent : responseText,
                    parsed: isJson ? null : parsedContent
                },
                executionTimeMs: Date.now() - start
            };
        } catch (error: any) {
            clearTimeout(timeoutId);
            this.abortController = null;
            return {
                status: ToolStatus.ERROR,
                error: error.name === 'AbortError' ? `Request timed out after ${timeoutMs}ms` : error.message,
                executionTimeMs: Date.now() - start
            };
        }
    }

    cancel(): void {
        if (this.abortController) {
            this.abortController.abort();
            this.abortController = null;
        }
    }

    getCapabilities(): string[] { return ['web_navigation', 'html_extraction', 'http_request']; }
}
