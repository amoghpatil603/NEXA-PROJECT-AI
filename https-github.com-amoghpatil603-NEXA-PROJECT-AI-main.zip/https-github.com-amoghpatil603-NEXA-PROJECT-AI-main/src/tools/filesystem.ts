import * as fs from 'fs/promises';
import * as path from 'path';
import { BaseTool, ToolCategory, ToolResult, ToolStatus } from './types';

export class FilesystemTool implements BaseTool {
    id = 'tool-filesystem';
    name = 'Filesystem';
    description = 'Reads and writes files';
    category = ToolCategory.SYSTEM;
    version = '1.0.0';
    
    private readonly workspaceRoot: string;

    constructor(workspaceRoot: string = process.cwd()) {
        this.workspaceRoot = path.resolve(workspaceRoot);
    }

    private resolveSafePath(unsafePath: string): string {
        const resolved = path.resolve(this.workspaceRoot, unsafePath);
        if (!resolved.startsWith(this.workspaceRoot)) {
            throw new Error(`Path ${unsafePath} is outside the allowed workspace.`);
        }
        return resolved;
    }

    async validate(input: any): Promise<boolean> {
        if (!input || typeof input.action !== 'string') return false;
        
        const validActions = [
            'read_file', 'write_file', 'create_folder', 'delete_file', 
            'delete_folder', 'rename', 'copy', 'move', 'list_dir', 
            'search', 'metadata'
        ];
        
        if (!validActions.includes(input.action)) return false;
        
        if (input.action === 'rename' || input.action === 'copy' || input.action === 'move') {
            return typeof input.source === 'string' && typeof input.destination === 'string';
        }
        if (input.action === 'search') {
            return typeof input.query === 'string' && (input.path === undefined || typeof input.path === 'string');
        }
        
        return typeof input.path === 'string';
    }

    async execute(input: any): Promise<ToolResult> {
        const start = Date.now();
        try {
            let data: any;

            switch (input.action) {
                case 'read_file':
                    const readPath = this.resolveSafePath(input.path);
                    data = await fs.readFile(readPath, 'utf-8');
                    break;
                case 'write_file':
                    const writePath = this.resolveSafePath(input.path);
                    await fs.writeFile(writePath, input.content || '', 'utf-8');
                    data = { success: true, path: input.path };
                    break;
                case 'create_folder':
                    const folderPath = this.resolveSafePath(input.path);
                    await fs.mkdir(folderPath, { recursive: true });
                    data = { success: true, path: input.path };
                    break;
                case 'delete_file':
                    const delFile = this.resolveSafePath(input.path);
                    await fs.unlink(delFile);
                    data = { success: true, path: input.path };
                    break;
                case 'delete_folder':
                    const delFolder = this.resolveSafePath(input.path);
                    await fs.rm(delFolder, { recursive: true, force: true });
                    data = { success: true, path: input.path };
                    break;
                case 'rename':
                case 'move':
                    const srcMove = this.resolveSafePath(input.source);
                    const destMove = this.resolveSafePath(input.destination);
                    await fs.rename(srcMove, destMove);
                    data = { success: true, source: input.source, destination: input.destination };
                    break;
                case 'copy':
                    const srcCopy = this.resolveSafePath(input.source);
                    const destCopy = this.resolveSafePath(input.destination);
                    const stat = await fs.stat(srcCopy);
                    if (stat.isDirectory()) {
                        await fs.cp(srcCopy, destCopy, { recursive: true });
                    } else {
                        await fs.copyFile(srcCopy, destCopy);
                    }
                    data = { success: true, source: input.source, destination: input.destination };
                    break;
                case 'list_dir':
                    const listPath = this.resolveSafePath(input.path);
                    const items = await fs.readdir(listPath, { withFileTypes: true });
                    data = items.map(item => ({
                        name: item.name,
                        isDirectory: item.isDirectory(),
                        isFile: item.isFile()
                    }));
                    break;
                case 'search':
                    const searchBase = input.path ? this.resolveSafePath(input.path) : this.workspaceRoot;
                    data = await this.recursiveSearch(searchBase, input.query);
                    break;
                case 'metadata':
                    const metaPath = this.resolveSafePath(input.path);
                    const fileStat = await fs.stat(metaPath);
                    data = {
                        size: fileStat.size,
                        created: fileStat.birthtime,
                        modified: fileStat.mtime,
                        isDirectory: fileStat.isDirectory(),
                        isFile: fileStat.isFile()
                    };
                    break;
                default:
                    throw new Error(`Unsupported action ${input.action}`);
            }

            return {
                status: ToolStatus.SUCCESS,
                data,
                executionTimeMs: Date.now() - start
            };
        } catch (error: any) {
            return {
                status: ToolStatus.ERROR,
                error: error.message,
                executionTimeMs: Date.now() - start
            };
        }
    }

    private async recursiveSearch(dir: string, query: string): Promise<string[]> {
        const results: string[] = [];
        const items = await fs.readdir(dir, { withFileTypes: true });
        for (const item of items) {
            const fullPath = path.join(dir, item.name);
            if (item.name.includes(query)) {
                results.push(path.relative(this.workspaceRoot, fullPath));
            }
            if (item.isDirectory()) {
                const subResults = await this.recursiveSearch(fullPath, query);
                results.push(...subResults);
            }
        }
        return results;
    }

    cancel(): void {}
    getCapabilities(): string[] { 
        return [
            'read_file', 'write_file', 'create_folder', 'delete_file', 
            'delete_folder', 'rename', 'copy', 'move', 'list_dir', 
            'search', 'metadata'
        ]; 
    }
}
