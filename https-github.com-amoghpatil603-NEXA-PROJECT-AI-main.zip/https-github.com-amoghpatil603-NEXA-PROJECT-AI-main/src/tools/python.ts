import { exec, ChildProcess } from 'child_process';
import * as fs from 'fs/promises';
import * as path from 'path';
import * as os from 'os';
import { BaseTool, ToolCategory, ToolResult, ToolStatus } from './types';

export class PythonTool implements BaseTool {
    id = 'tool-python';
    name = 'Python';
    description = 'Executes Python scripts';
    category = ToolCategory.EXECUTION;
    version = '1.0.0';

    private activeProcess: ChildProcess | null = null;

    async validate(input: any): Promise<boolean> {
        return typeof input?.code === 'string' || typeof input?.scriptPath === 'string';
    }

    async execute(input: any): Promise<ToolResult> {
        const start = Date.now();
        const timeoutMs = input.timeout || 30000;
        let scriptToRun = '';
        let isTemp = false;

        try {
            if (input.scriptPath) {
                scriptToRun = path.resolve(process.cwd(), input.scriptPath);
            } else if (input.code) {
                scriptToRun = path.join(os.tmpdir(), `script_${Date.now()}_${Math.floor(Math.random() * 1000)}.py`);
                await fs.writeFile(scriptToRun, input.code, 'utf-8');
                isTemp = true;
            } else {
                throw new Error("Must provide 'code' or 'scriptPath'");
            }

            return await new Promise((resolve) => {
                this.activeProcess = exec(`python3 ${scriptToRun}`, { timeout: timeoutMs }, async (error, stdout, stderr) => {
                    this.activeProcess = null;
                    if (isTemp) {
                        try { await fs.unlink(scriptToRun); } catch (_) {}
                    }

                    if (error) {
                        if (error.killed) {
                            resolve({
                                status: ToolStatus.ERROR,
                                error: `Python execution timed out after ${timeoutMs}ms`,
                                data: { stdout, stderr, exitCode: error.code },
                                executionTimeMs: Date.now() - start
                            });
                            return;
                        }
                        resolve({
                            status: ToolStatus.SUCCESS,
                            data: { stdout, stderr, exitCode: error.code || 1 },
                            executionTimeMs: Date.now() - start
                        });
                        return;
                    }
                    
                    resolve({
                        status: ToolStatus.SUCCESS,
                        data: { stdout, stderr, exitCode: 0 },
                        executionTimeMs: Date.now() - start
                    });
                });
            });

        } catch (error: any) {
            return {
                status: ToolStatus.ERROR,
                error: error.message,
                executionTimeMs: Date.now() - start
            };
        }
    }

    cancel(): void {
        if (this.activeProcess) {
            this.activeProcess.kill('SIGINT');
            this.activeProcess = null;
        }
    }

    getCapabilities(): string[] { return ['execute_code', 'data_analysis']; }
}
