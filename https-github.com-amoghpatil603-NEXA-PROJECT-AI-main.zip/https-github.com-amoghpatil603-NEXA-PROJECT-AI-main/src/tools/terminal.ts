import { exec, ChildProcess } from 'child_process';
import { BaseTool, ToolCategory, ToolResult, ToolStatus } from './types';

export class TerminalTool implements BaseTool {
    id = 'tool-terminal';
    name = 'Terminal';
    description = 'Executes shell commands';
    category = ToolCategory.EXECUTION;
    version = '1.0.0';
    
    private activeProcess: ChildProcess | null = null;

    async validate(input: any): Promise<boolean> {
        return typeof input?.command === 'string';
    }

    async execute(input: any): Promise<ToolResult> {
        const start = Date.now();
        const timeoutMs = input.timeout || 30000; // 30 seconds default
        
        return new Promise((resolve) => {
            let stderrData = '';
            let stdoutData = '';

            // Security check: prevent obviously dangerous commands (basic)
            const lowerCmd = input.command.toLowerCase();
            if (lowerCmd.includes('rm -rf /') || lowerCmd.includes('mkfs')) {
                resolve({
                    status: ToolStatus.ERROR,
                    error: 'Command blocked for security reasons',
                    executionTimeMs: Date.now() - start
                });
                return;
            }

            try {
                this.activeProcess = exec(input.command, { 
                    cwd: input.cwd || process.cwd(),
                    timeout: timeoutMs
                }, (error, stdout, stderr) => {
                    this.activeProcess = null;
                    
                    if (error) {
                        // Check if killed due to timeout
                        if (error.killed) {
                             resolve({
                                 status: ToolStatus.ERROR,
                                 error: `Command timed out after ${timeoutMs}ms`,
                                 data: { stdout, stderr, exitCode: error.code },
                                 executionTimeMs: Date.now() - start
                             });
                             return;
                        }

                        resolve({
                            status: ToolStatus.SUCCESS,
                            data: { stdout, stderr, exitCode: error.code || 1 },
                            executionTimeMs: Date.now() - start
                        });
                        return;
                    }

                    resolve({
                        status: ToolStatus.SUCCESS,
                        data: { stdout, stderr, exitCode: 0 },
                        executionTimeMs: Date.now() - start
                    });
                });
            } catch (err: any) {
                this.activeProcess = null;
                resolve({
                    status: ToolStatus.ERROR,
                    error: err.message,
                    executionTimeMs: Date.now() - start
                });
            }
        });
    }

    cancel(): void {
        if (this.activeProcess) {
            this.activeProcess.kill('SIGINT');
            this.activeProcess = null;
        }
    }

    getCapabilities(): string[] { return ['shell_execution', 'command_line']; }
}
