export class ProgressTracker {
  track(goalId: string, step: string) {
    console.log(`[ProgressTracker] Goal ${goalId} step: ${step}`);
  }
}
