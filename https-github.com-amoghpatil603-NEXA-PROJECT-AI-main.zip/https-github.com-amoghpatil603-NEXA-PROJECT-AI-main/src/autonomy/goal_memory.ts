export class GoalMemory {
  saveLesson(goalId: string, lesson: string) {
    console.log(`[GoalMemory] Saved lesson for ${goalId}`);
  }
}
