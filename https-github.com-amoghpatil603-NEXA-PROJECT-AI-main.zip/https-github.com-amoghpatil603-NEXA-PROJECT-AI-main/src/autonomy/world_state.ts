import { WorldState as WorldStateInterface } from './types';

export class WorldState {
  private state: WorldStateInterface = {
    currentTask: null,
    completedTasks: [],
    availableTools: [],
    availableAgents: [],
    conversationContext: {},
    memorySummary: '',
    knowledgeSummary: ''
  };

  getState() {
    return this.state;
  }
}
