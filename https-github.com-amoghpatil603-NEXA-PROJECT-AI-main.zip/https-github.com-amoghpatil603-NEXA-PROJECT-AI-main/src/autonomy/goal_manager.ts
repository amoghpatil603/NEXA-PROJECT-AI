import { Goal } from './types';

export class GoalManager {
  private goals: Goal[] = [];

  addGoal(goal: Goal) {
    this.goals.push(goal);
  }
}
