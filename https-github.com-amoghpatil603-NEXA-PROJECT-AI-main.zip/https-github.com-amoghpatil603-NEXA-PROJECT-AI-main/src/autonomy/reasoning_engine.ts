import { Goal } from './types';
import { plannerEngine } from '../planner';
import { executionEngine } from '../execution';
import { knowledgeEngine } from '../rag';

export class ReasoningEngine {
  async analyzeAndExecute(goal: Goal) {
    try {
      console.log(`[ReasoningEngine] Analyzing goal: ${goal.objective}`);
      
      // Analyze problem
      const plan = await plannerEngine.generatePlan(goal.objective);
      
      // Execute
      await executionEngine.executePlan(plan);
      
      console.log(`[ReasoningEngine] Goal ${goal.id} executed successfully.`);
    } catch (error) {
      console.error(`[ReasoningEngine] Error executing goal ${goal.id}:`, error);
      throw error;
    }
  }
}
