import { Goal, GoalStatus } from './types';
import { WorldState } from './world_state';
import { ReasoningEngine } from './reasoning_engine';

export class AutonomyManager {
  private goals: Goal[] = [];
  private reasoningEngine: ReasoningEngine = new ReasoningEngine();

  async startGoal(objective: string): Promise<string> {
    const goal: Goal = {
      id: `goal-${Date.now()}`,
      objective,
      priority: 1,
      status: GoalStatus.IN_PROGRESS,
      dependencies: [],
      createdAt: Date.now()
    };
    this.goals.push(goal);
    
    // Start processing
    this.reasoningEngine.analyzeAndExecute(goal);
    
    return goal.id;
  }

  pauseGoal(goalId: string) {
    const goal = this.goals.find(g => g.id === goalId);
    if (goal) goal.status = GoalStatus.PENDING;
  }
  
  resumeGoal(goalId: string) {
    const goal = this.goals.find(g => g.id === goalId);
    if (goal) goal.status = GoalStatus.IN_PROGRESS;
  }
  
  cancelGoal(goalId: string) {
    const goal = this.goals.find(g => g.id === goalId);
    if (goal) goal.status = GoalStatus.CANCELLED;
  }
  
  getGoalStatus(goalId: string): GoalStatus {
    return this.goals.find(g => g.id === goalId)?.status || GoalStatus.FAILED;
  }
  
  listGoals(): Goal[] {
    return this.goals;
  }
}

export const autonomyManager = new AutonomyManager();
