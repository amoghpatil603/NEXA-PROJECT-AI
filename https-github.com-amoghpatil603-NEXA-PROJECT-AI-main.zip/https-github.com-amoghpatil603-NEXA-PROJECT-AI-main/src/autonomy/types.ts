export enum GoalStatus {
  PENDING = 'PENDING',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED',
  FAILED = 'FAILED'
}

export interface Goal {
  id: string;
  objective: string;
  priority: number;
  status: GoalStatus;
  dependencies: string[];
  createdAt: number;
}

export interface WorldState {
  currentTask: string | null;
  completedTasks: string[];
  availableTools: string[];
  availableAgents: string[];
  conversationContext: any;
  memorySummary: string;
  knowledgeSummary: string;
}
