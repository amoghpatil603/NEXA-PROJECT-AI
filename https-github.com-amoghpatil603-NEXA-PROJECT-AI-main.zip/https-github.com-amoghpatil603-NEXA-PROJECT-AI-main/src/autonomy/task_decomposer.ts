import { Goal } from './types';
import { plannerEngine } from '../planner';

export class TaskDecomposer {
  async decompose(goal: Goal) {
    return await plannerEngine.generatePlan(goal.objective);
  }
}
