export class ReflectionEngine {
  evaluate(goalId: string, result: any) {
    if (result.success) {
      console.log(`[ReflectionEngine] Goal ${goalId} evaluated as SUCCESS`);
    } else {
      console.log(`[ReflectionEngine] Goal ${goalId} evaluated as FAILED: ${result.error}`);
    }
  }
}
