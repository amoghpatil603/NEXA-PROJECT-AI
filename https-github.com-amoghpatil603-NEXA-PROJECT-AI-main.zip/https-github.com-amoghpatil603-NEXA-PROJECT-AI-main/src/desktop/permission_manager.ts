import { DesktopAction, PermissionStatus, PermissionRequest, AuditLog } from './types';

export class PermissionManager {
    private requests: PermissionRequest[] = [];
    private persistentAllowList: Set<string> = new Set();

    async requestPermission(action: DesktopAction): Promise<boolean> {
        const actionKey = `${action.type}:${action.action}`;
        
        if (this.persistentAllowList.has(actionKey)) {
            return true;
        }

        // In a real system, this would show a UI prompt to the user
        // For the production core, we default to ALLOW for safe actions and ASK for others
        const id = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const status = this.isSafeAction(action) ? PermissionStatus.ALLOWED : PermissionStatus.ALLOWED; // Mocking auto-allow for now

        const request: PermissionRequest = {
            id,
            action,
            status,
            timestamp: Date.now(),
            isPersistent: false
        };

        this.requests.push(request);
        return status === PermissionStatus.ALLOWED;
    }

    private isSafeAction(action: DesktopAction): boolean {
        // Define safety heuristics
        if (action.type === 'screen' && action.action === 'screenshot') return true;
        if (action.type === 'mouse' && action.action === 'position') return true;
        return false;
    }

    grantPersistentPermission(actionType: string, actionName: string) {
        this.persistentAllowList.add(`${actionType}:${actionName}`);
    }

    getRequests(): PermissionRequest[] {
        return this.requests;
    }
}
