export class KeyboardController {
    async type(text: string): Promise<void> {
        console.log(`[Keyboard] Typing: "${text}"`);
    }

    async pressKey(key: string): Promise<void> {
        console.log(`[Keyboard] Pressing key: ${key}`);
    }

    async combination(keys: string[]): Promise<void> {
        console.log(`[Keyboard] Combination: ${keys.join('+')}`);
    }

    async hotkey(name: string): Promise<void> {
        console.log(`[Keyboard] Hotkey: ${name}`);
    }

    async paste(): Promise<void> {
        console.log(`[Keyboard] Pasting from clipboard`);
    }
}
