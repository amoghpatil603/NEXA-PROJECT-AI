export class ClipboardManager {
    private history: string[] = [];

    async read(): Promise<string> {
        return this.history[this.history.length - 1] || "";
    }

    async write(text: string): Promise<void> {
        console.log(`[Clipboard] Writing: "${text}"`);
        this.history.push(text);
        if (this.history.length > 50) this.history.shift();
    }

    async getHistory(): Promise<string[]> {
        return [...this.history];
    }
}
