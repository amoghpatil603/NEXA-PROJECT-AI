import { DesktopAction, AuditLog, PermissionStatus } from './types';

export class DesktopSecurity {
    private auditLogs: AuditLog[] = [];

    logAction(action: DesktopAction, status: PermissionStatus, reason?: string) {
        const log: AuditLog = {
            id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            timestamp: Date.now(),
            action,
            status,
            reason
        };
        this.auditLogs.push(log);
        console.log(`[DesktopSecurity] ${status}: ${action.type}.${action.action}`);
    }

    isDestructive(action: DesktopAction): boolean {
        const destructiveActions = ['terminate', 'close', 'delete', 'format'];
        return destructiveActions.includes(action.action.toLowerCase());
    }

    getAuditLogs(): AuditLog[] {
        return this.auditLogs;
    }
}
