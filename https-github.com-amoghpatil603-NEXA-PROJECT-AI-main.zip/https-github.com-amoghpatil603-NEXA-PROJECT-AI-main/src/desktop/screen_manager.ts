export class ScreenManager {
    async takeScreenshot(): Promise<string> {
        const path = `/tmp/screenshot_${Date.now()}.png`;
        console.log(`[Screen] Taking screenshot: ${path}`);
        return path;
    }

    async captureRegion(x: number, y: number, width: number, height: number): Promise<string> {
        const path = `/tmp/region_${Date.now()}.png`;
        console.log(`[Screen] Capturing region (${x}, ${y}, ${width}, ${height}): ${path}`);
        return path;
    }

    async getResolution(): Promise<{ width: number; height: number }> {
        return { width: 1920, height: 1080 };
    }

    async listMonitors(): Promise<any[]> {
        return [{ id: 1, name: 'Main Monitor', resolution: '1920x1080' }];
    }
}
