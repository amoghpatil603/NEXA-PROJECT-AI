import { MousePosition } from './types';

export class MouseController {
    async move(x: number, y: number): Promise<void> {
        console.log(`[Mouse] Moving to (${x}, ${y})`);
    }

    async click(button: 'left' | 'right' | 'middle' = 'left'): Promise<void> {
        console.log(`[Mouse] ${button} click`);
    }

    async doubleClick(): Promise<void> {
        console.log(`[Mouse] Double click`);
    }

    async drag(from: MousePosition, to: MousePosition): Promise<void> {
        console.log(`[Mouse] Dragging from (${from.x}, ${from.y}) to (${to.x}, ${to.y})`);
    }

    async scroll(delta: number): Promise<void> {
        console.log(`[Mouse] Scrolling ${delta}`);
    }

    async getPosition(): Promise<MousePosition> {
        return { x: 500, y: 500 };
    }
}
