import { WindowManager } from './window_manager';
import { MouseController } from './mouse_controller';
import { KeyboardController } from './keyboard_controller';
import { ClipboardManager } from './clipboard';
import { ScreenManager } from './screen_manager';
import { ApplicationManager } from './application_manager';
import { PermissionManager } from './permission_manager';
import { DesktopSecurity } from './security';
import { DesktopAction, PermissionStatus } from './types';

export class DesktopManager {
    constructor(
        public windows: WindowManager,
        public mouse: MouseController,
        public keyboard: KeyboardController,
        public clipboard: ClipboardManager,
        public screen: ScreenManager,
        public apps: ApplicationManager,
        public permissions: PermissionManager,
        public security: DesktopSecurity
    ) {}

    async execute(action: DesktopAction): Promise<any> {
        // Security & Permission check
        const allowed = await this.permissions.requestPermission(action);
        if (!allowed) {
            this.security.logAction(action, PermissionStatus.DENIED, 'User rejected');
            throw new Error(`Permission denied for desktop action: ${action.type}.${action.action}`);
        }

        this.security.logAction(action, PermissionStatus.ALLOWED);

        switch (action.type) {
            case 'window':
                return this.handleWindowAction(action);
            case 'mouse':
                return this.handleMouseAction(action);
            case 'keyboard':
                return this.handleKeyboardAction(action);
            case 'clipboard':
                return this.handleClipboardAction(action);
            case 'screen':
                return this.handleScreenAction(action);
            case 'application':
                return this.handleAppAction(action);
            default:
                throw new Error(`Unknown desktop action type: ${action.type}`);
        }
    }

    private async handleWindowAction(action: DesktopAction): Promise<any> {
        switch (action.action) {
            case 'list': return this.windows.listWindows();
            case 'focused': return this.windows.getFocusedWindow();
            case 'activate': return this.windows.activateWindow(action.params.id);
            case 'minimize': return this.windows.minimizeWindow(action.params.id);
            case 'maximize': return this.windows.maximizeWindow(action.params.id);
            case 'restore': return this.windows.restoreWindow(action.params.id);
            case 'close': return this.windows.closeWindow(action.params.id);
            default: throw new Error(`Unknown window action: ${action.action}`);
        }
    }

    private async handleMouseAction(action: DesktopAction): Promise<any> {
        switch (action.action) {
            case 'move': return this.mouse.move(action.params.x, action.params.y);
            case 'click': return this.mouse.click(action.params?.button);
            case 'double_click': return this.mouse.doubleClick();
            case 'drag': return this.mouse.drag(action.params.from, action.params.to);
            case 'scroll': return this.mouse.scroll(action.params.delta);
            case 'position': return this.mouse.getPosition();
            default: throw new Error(`Unknown mouse action: ${action.action}`);
        }
    }

    private async handleKeyboardAction(action: DesktopAction): Promise<any> {
        switch (action.action) {
            case 'type': return this.keyboard.type(action.params.text);
            case 'press': return this.keyboard.pressKey(action.params.key);
            case 'combination': return this.keyboard.combination(action.params.keys);
            case 'hotkey': return this.keyboard.hotkey(action.params.name);
            case 'paste': return this.keyboard.paste();
            default: throw new Error(`Unknown keyboard action: ${action.action}`);
        }
    }

    private async handleClipboardAction(action: DesktopAction): Promise<any> {
        switch (action.action) {
            case 'read': return this.clipboard.read();
            case 'write': return this.clipboard.write(action.params.text);
            case 'history': return this.clipboard.getHistory();
            default: throw new Error(`Unknown clipboard action: ${action.action}`);
        }
    }

    private async handleScreenAction(action: DesktopAction): Promise<any> {
        switch (action.action) {
            case 'screenshot': return this.screen.takeScreenshot();
            case 'region': return this.screen.captureRegion(action.params.x, action.params.y, action.params.width, action.params.height);
            case 'resolution': return this.screen.getResolution();
            case 'monitors': return this.screen.listMonitors();
            default: throw new Error(`Unknown screen action: ${action.action}`);
        }
    }

    private async handleAppAction(action: DesktopAction): Promise<any> {
        switch (action.action) {
            case 'launch': return this.apps.launch(action.params.path, action.params.args);
            case 'terminate': return this.apps.terminate(action.params.pid);
            case 'list': return this.apps.listRunning();
            default: throw new Error(`Unknown application action: ${action.action}`);
        }
    }
}
