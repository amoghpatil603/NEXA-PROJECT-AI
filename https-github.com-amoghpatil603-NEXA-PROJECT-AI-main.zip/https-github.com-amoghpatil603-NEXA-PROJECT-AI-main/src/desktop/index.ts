import { WindowManager } from './window_manager';
import { MouseController } from './mouse_controller';
import { KeyboardController } from './keyboard_controller';
import { ClipboardManager } from './clipboard';
import { ScreenManager } from './screen_manager';
import { ApplicationManager } from './application_manager';
import { PermissionManager } from './permission_manager';
import { DesktopSecurity } from './security';
import { DesktopManager } from './desktop_manager';

export * from './types';
export * from './window_manager';
export * from './mouse_controller';
export * from './keyboard_controller';
export * from './clipboard';
export * from './screen_manager';
export * from './application_manager';
export * from './permission_manager';
export * from './security';
export * from './desktop_manager';

const windows = new WindowManager();
const mouse = new MouseController();
const keyboard = new KeyboardController();
const clipboard = new ClipboardManager();
const screen = new ScreenManager();
const apps = new ApplicationManager();
const permissions = new PermissionManager();
const security = new DesktopSecurity();

export const desktopEngine = new DesktopManager(
    windows,
    mouse,
    keyboard,
    clipboard,
    screen,
    apps,
    permissions,
    security
);
