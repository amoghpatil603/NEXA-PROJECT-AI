export interface DesktopWindow {
    id: string;
    title: string;
    owner: string;
    bounds: { x: number; y: number; width: number; height: number };
    isActive: boolean;
    isMinimized: boolean;
    isMaximized: boolean;
}

export interface MousePosition {
    x: number;
    y: number;
}

export interface RunningApplication {
    pid: number;
    name: string;
    path: string;
    startTime: number;
}

export interface DesktopAction {
    type: 'mouse' | 'keyboard' | 'window' | 'clipboard' | 'screen' | 'application';
    action: string;
    params?: any;
}

export enum PermissionStatus {
    ALLOWED = 'ALLOWED',
    DENIED = 'DENIED',
    PENDING = 'PENDING'
}

export interface PermissionRequest {
    id: string;
    action: DesktopAction;
    status: PermissionStatus;
    timestamp: number;
    isPersistent: boolean;
}

export interface AuditLog {
    id: string;
    timestamp: number;
    action: DesktopAction;
    status: PermissionStatus;
    reason?: string;
}
