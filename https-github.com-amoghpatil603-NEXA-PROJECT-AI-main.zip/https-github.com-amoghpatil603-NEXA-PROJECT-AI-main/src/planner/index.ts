import { Subsystem } from '../types';

export enum TaskStatus {
    PENDING = 'PENDING',
    READY = 'READY',
    RUNNING = 'RUNNING',
    COMPLETED = 'COMPLETED',
    FAILED = 'FAILED',
    SKIPPED = 'SKIPPED',
    CANCELLED = 'CANCELLED'
}

export enum PlanType {
    SINGLE_STEP = 'SINGLE_STEP',
    MULTI_STEP = 'MULTI_STEP',
    ITERATIVE = 'ITERATIVE'
}

export enum PlanStatus {
    CREATED = 'CREATED',
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    FAILED = 'FAILED'
}

export interface PlannerTask {
    id: string;
    description: string;
    objective: string;
    requiredSubsystem: Subsystem;
    dependencies: string[]; // IDs of tasks that must complete first
    status: TaskStatus;
}

export interface ExecutionPlan {
    id: string;
    goal: string;
    type: PlanType;
    tasks: PlannerTask[];
    status: PlanStatus;
}

export class NexaPlanner {
    /**
     * Analyzes a user goal and produces an execution plan.
     */
    async generatePlan(goal: string, preferredSubsystem?: Subsystem): Promise<ExecutionPlan> {
        console.log(`[Planner] Generating plan for goal: "${goal}"`);
        const lowerGoal = goal.toLowerCase();
        
        let type = PlanType.SINGLE_STEP;
        const tasks: PlannerTask[] = [];

        // Basic heuristic for planning.
        // A sophisticated implementation would use an LLM via the Router/Connector to decompose the goal.

        if (lowerGoal.includes('step-by-step') || lowerGoal.includes('plan') || lowerGoal.includes('first') && lowerGoal.includes('then')) {
            type = PlanType.MULTI_STEP;
        } else if (lowerGoal.includes('continuously') || lowerGoal.includes('monitor') || lowerGoal.includes('iterative')) {
            type = PlanType.ITERATIVE;
        }

        // Handle preferred subsystem
        if (preferredSubsystem && type === PlanType.SINGLE_STEP) {
            tasks.push({
                id: 'task-1',
                description: 'Process user request',
                objective: goal,
                requiredSubsystem: preferredSubsystem,
                dependencies: [],
                status: TaskStatus.PENDING
            });
            return {
                id: `plan-${Date.now()}`,
                goal,
                type,
                tasks,
                status: PlanStatus.CREATED
            };
        }

        // Example Multi-step plan logic
        if (type === PlanType.MULTI_STEP) {
            if (lowerGoal.includes('research') && lowerGoal.includes('document')) {
                tasks.push({
                    id: 'task-1',
                    description: 'Search documents for relevant information',
                    objective: 'Retrieve context',
                    requiredSubsystem: Subsystem.RAG,
                    dependencies: [],
                    status: TaskStatus.PENDING
                });
                tasks.push({
                    id: 'task-2',
                    description: 'Synthesize findings',
                    objective: 'Generate answer',
                    requiredSubsystem: Subsystem.NORMAL,
                    dependencies: ['task-1'],
                    status: TaskStatus.PENDING
                });
            } else {
                // Generic multi-step fallback
                tasks.push({
                    id: 'task-1',
                    description: 'Analyze initial request',
                    objective: 'Understand constraints',
                    requiredSubsystem: Subsystem.NORMAL,
                    dependencies: [],
                    status: TaskStatus.PENDING
                });
                tasks.push({
                    id: 'task-2',
                    description: 'Execute request',
                    objective: 'Provide final response',
                    requiredSubsystem: Subsystem.NORMAL,
                    dependencies: ['task-1'],
                    status: TaskStatus.PENDING
                });
            }
        } else {
            // Single step fallback
            let subsystem = Subsystem.NORMAL;
            if (lowerGoal.includes('calculate') || lowerGoal.includes('weather')) subsystem = Subsystem.TOOL_ENGINE;
            else if (lowerGoal.includes('remember')) subsystem = Subsystem.MEMORY;
            else if (
                lowerGoal.includes('search') ||
                lowerGoal.includes('read this project') ||
                lowerGoal.includes('summarize these files') ||
                lowerGoal.includes('explain this repository') ||
                lowerGoal.includes('find information') ||
                lowerGoal.includes('document')
            ) subsystem = Subsystem.RAG;
            else if (
                lowerGoal.includes('describe this image') ||
                lowerGoal.includes('read this screenshot') ||
                lowerGoal.includes('what is on my screen') ||
                lowerGoal.includes('analyze this ui') ||
                lowerGoal.includes('image') ||
                lowerGoal.includes('vision')
            ) subsystem = Subsystem.VISION;
            else if (
                lowerGoal.includes('listen') ||
                lowerGoal.includes('speak') ||
                lowerGoal.includes('start voice chat') ||
                lowerGoal.includes('read aloud') ||
                lowerGoal.includes('voice')
            ) subsystem = Subsystem.VOICE;
            else if (
                lowerGoal.includes('open') ||
                lowerGoal.includes('close') ||
                lowerGoal.includes('click') ||
                lowerGoal.includes('type') ||
                lowerGoal.includes('launch') ||
                lowerGoal.includes('screenshot') ||
                lowerGoal.includes('desktop') ||
                lowerGoal.includes('window') ||
                lowerGoal.includes('mouse') ||
                lowerGoal.includes('keyboard') ||
                lowerGoal.includes('clipboard')
            ) subsystem = Subsystem.DESKTOP;
            else if (
                lowerGoal.includes('research') ||
                lowerGoal.includes('code') ||
                lowerGoal.includes('plan') ||
                lowerGoal.includes('business') ||
                lowerGoal.includes('electronics') ||
                lowerGoal.includes('agent')
            ) subsystem = Subsystem.AGENTS;
            
            tasks.push({
                id: 'task-1',
                description: 'Process user request',
                objective: 'Directly address the user goal',
                requiredSubsystem: subsystem,
                dependencies: [],
                status: TaskStatus.PENDING
            });
        }

        const plan: ExecutionPlan = {
            id: `plan-${Date.now()}`,
            goal,
            type,
            status: PlanStatus.CREATED,
            tasks
        };

        console.log(`[Planner] Generated ${type} plan with ${tasks.length} tasks.`);
        return plan;
    }
}

export const plannerEngine = new NexaPlanner();
