import { BaseAgent } from './base_agent';
import { AgentTask, AgentResult, AgentStatus } from './types';
import { plannerEngine } from '../planner';
import { executionEngine } from '../execution';
import { Subsystem } from '../types';

export class CodingAgent extends BaseAgent {
    constructor() {
        super('agent-coding', 'Coding Agent', {
            canCode: true,
            canResearch: false,
            canPlan: true,
            canAnalyzeBusiness: false,
            canDesignElectronics: false
        });
    }

    async execute(task: AgentTask): Promise<AgentResult> {
        if (this.isExecuting) {
            return {
                taskId: task.id,
                success: false,
                output: null,
                error: 'Recursion detected: Agent is already executing'
            };
        }
        this.isExecuting = true;
        this.status = AgentStatus.RUNNING;
        console.log(`[CodingAgent] Executing task: ${task.objective}`);
        
        try {
            // Use planner to decompose coding task, forcing TOOL_ENGINE to avoid recursion
            const plan = await plannerEngine.generatePlan(`Write code for: ${task.objective}`, Subsystem.TOOL_ENGINE);
            
            // Use execution engine to run the plan
            await executionEngine.executePlan(plan);
            
            const results = executionEngine.getExecutionHistory();
            const summary = results.map(r => `Task ${r.taskId}: ${r.output?.status || 'DONE'}`).join(', ');
            
            this.status = AgentStatus.COMPLETED;
            return {
                taskId: task.id,
                success: true,
                output: `Code generation complete: ${summary}`
            };
        } catch (error: any) {
            this.status = AgentStatus.FAILED;
            return {
                taskId: task.id,
                success: false,
                output: null,
                error: error.message
            };
        } finally {
            this.isExecuting = false;
        }
    }
}
