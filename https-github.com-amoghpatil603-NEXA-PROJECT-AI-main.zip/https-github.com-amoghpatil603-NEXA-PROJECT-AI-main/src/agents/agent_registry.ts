import { agentManager } from './agent_manager';
import { CodingAgent } from './coding_agent';
import { ResearchAgent } from './research_agent';
import { BusinessAgent } from './business_agent';
import { PlanningAgent } from './planning_agent';
import { ElectronicsAgent } from './electronics_agent';

export function initializeAgentRegistry() {
    agentManager.registerAgent(new CodingAgent());
    agentManager.registerAgent(new ResearchAgent());
    agentManager.registerAgent(new BusinessAgent());
    agentManager.registerAgent(new PlanningAgent());
    agentManager.registerAgent(new ElectronicsAgent());
}
