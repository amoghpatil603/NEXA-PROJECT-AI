import { IAgent, AgentStatus, AgentTask, AgentResult } from './types';

export class AgentManager {
    private agents: Map<string, IAgent> = new Map();

    registerAgent(agent: IAgent) {
        this.agents.set(agent.id, agent);
        console.log(`[AgentManager] Registered agent: ${agent.name} (${agent.id})`);
    }

    unregisterAgent(id: string) {
        this.agents.delete(id);
        console.log(`[AgentManager] Unregistered agent: ${id}`);
    }

    getAgent(id: string): IAgent | undefined {
        return this.agents.get(id);
    }

    listAgents(): IAgent[] {
        return Array.from(this.agents.values());
    }

    async executeAgent(id: string, task: AgentTask): Promise<AgentResult> {
        const agent = this.getAgent(id);
        if (!agent) throw new Error(`Agent ${id} not found`);
        return await agent.execute(task);
    }

    async pauseAgent(id: string): Promise<void> {
        const agent = this.getAgent(id);
        if (agent) await agent.pause();
    }

    async resumeAgent(id: string): Promise<void> {
        const agent = this.getAgent(id);
        if (agent) await agent.resume();
    }

    async cancelAgent(id: string): Promise<void> {
        const agent = this.getAgent(id);
        if (agent) await agent.cancel();
    }
}

export const agentManager = new AgentManager();
