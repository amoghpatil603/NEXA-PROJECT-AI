import { agentManager } from './agent_manager';
import { initializeAgentRegistry } from './agent_registry';

export * from './types';
export * from './base_agent';
export * from './agent_manager';
export * from './agent_registry';
export * from './agent_context';
export * from './agent_memory';
export * from './coding_agent';
export * from './research_agent';
export * from './business_agent';
export * from './planning_agent';
export * from './electronics_agent';

// Auto-initialize the registry
initializeAgentRegistry();

export const agentsEngine = agentManager;
