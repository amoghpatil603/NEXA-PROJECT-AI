import { AgentTask, AgentResult } from './types';

export interface AgentContext {
    id: string;
    sharedState: Record<string, any>;
    delegatedTasks: AgentTask[];
    results: Record<string, AgentResult>;
    conflicts: string[];
}

export class AgentContextManager {
    private contexts: Map<string, AgentContext> = new Map();

    createContext(id: string): AgentContext {
        const context: AgentContext = {
            id,
            sharedState: {},
            delegatedTasks: [],
            results: {},
            conflicts: []
        };
        this.contexts.set(id, context);
        return context;
    }

    getContext(id: string): AgentContext | undefined {
        return this.contexts.get(id);
    }

    updateSharedState(id: string, key: string, value: any) {
        const context = this.getContext(id);
        if (context) {
            context.sharedState[key] = value;
            // Simple conflict detection: if state is overwritten by different values rapidly
            console.log(`[AgentContext] Updated ${key} in context ${id}`);
        }
    }

    delegateTask(contextId: string, task: AgentTask) {
        const context = this.getContext(contextId);
        if (context) {
            context.delegatedTasks.push(task);
            console.log(`[AgentContext] Task ${task.id} delegated in context ${contextId}`);
        }
    }

    recordResult(contextId: string, result: AgentResult) {
        const context = this.getContext(contextId);
        if (context) {
            context.results[result.taskId] = result;
        }
    }
}

export const agentContextManager = new AgentContextManager();
