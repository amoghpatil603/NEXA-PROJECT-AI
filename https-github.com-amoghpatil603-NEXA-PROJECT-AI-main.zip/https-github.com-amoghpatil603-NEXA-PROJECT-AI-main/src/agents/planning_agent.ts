import { BaseAgent } from './base_agent';
import { AgentTask, AgentResult, AgentStatus } from './types';
import { plannerEngine } from '../planner';

export class PlanningAgent extends BaseAgent {
    constructor() {
        super('agent-planning', 'Planning Agent', {
            canCode: false,
            canResearch: false,
            canPlan: true,
            canAnalyzeBusiness: false,
            canDesignElectronics: false
        });
    }

    async execute(task: AgentTask): Promise<AgentResult> {
        this.status = AgentStatus.RUNNING;
        console.log(`[PlanningAgent] Planning: ${task.objective}`);
        
        try {
            const plan = await plannerEngine.generatePlan(task.objective);
            
            this.status = AgentStatus.COMPLETED;
            return {
                taskId: task.id,
                success: true,
                output: plan
            };
        } catch (error: any) {
            this.status = AgentStatus.FAILED;
            return {
                taskId: task.id,
                success: false,
                output: null,
                error: error.message
            };
        }
    }
}
