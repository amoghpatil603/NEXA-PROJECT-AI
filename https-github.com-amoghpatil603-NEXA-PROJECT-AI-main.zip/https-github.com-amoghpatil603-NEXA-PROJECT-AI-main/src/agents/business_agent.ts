import { BaseAgent } from './base_agent';
import { AgentTask, AgentResult, AgentStatus } from './types';
import { plannerEngine } from '../planner';
import { executionEngine } from '../execution';
import { Subsystem } from '../types';

export class BusinessAgent extends BaseAgent {
    constructor() {
        super('agent-business', 'Business Agent', {
            canCode: false,
            canResearch: true,
            canPlan: true,
            canAnalyzeBusiness: true,
            canDesignElectronics: false
        });
    }

    async execute(task: AgentTask): Promise<AgentResult> {
        if (this.isExecuting) {
            return {
                taskId: task.id,
                success: false,
                output: null,
                error: 'Recursion detected: Agent is already executing'
            };
        }
        this.isExecuting = true;
        this.status = AgentStatus.RUNNING;
        console.log(`[BusinessAgent] Analyzing business: ${task.objective}`);
        
        try {
            const plan = await plannerEngine.generatePlan(`Analyze business case for: ${task.objective}`, Subsystem.TOOL_ENGINE);
            await executionEngine.executePlan(plan);
            const results = executionEngine.getExecutionHistory();
            const summary = results.map(r => `Task ${r.taskId}: ${r.output?.status || 'DONE'}`).join(', ');
            
            this.status = AgentStatus.COMPLETED;
            return {
                taskId: task.id,
                success: true,
                output: `Business analysis complete: ${summary}`
            };
        } catch (error: any) {
            this.status = AgentStatus.FAILED;
            return {
                taskId: task.id,
                success: false,
                output: null,
                error: error.message
            };
        } finally {
            this.isExecuting = false;
        }
    }
}
