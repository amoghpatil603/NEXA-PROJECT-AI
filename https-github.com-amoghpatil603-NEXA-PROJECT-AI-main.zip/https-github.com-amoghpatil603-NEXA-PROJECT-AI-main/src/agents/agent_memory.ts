import { memoryEngine, MemoryCategory } from '../memory';

export class AgentMemoryManager {
    async storeResult(agentName: string, taskId: string, result: any) {
        const content = `Agent [${agentName}] completed task [${taskId}] with result: ${JSON.stringify(result)}`;
        await memoryEngine.processInput(content, MemoryCategory.WORKSPACE);
    }

    async retrieveRelevantResults(query: string) {
        return await memoryEngine.retrieveContext(query);
    }
}

export const agentMemoryManager = new AgentMemoryManager();
