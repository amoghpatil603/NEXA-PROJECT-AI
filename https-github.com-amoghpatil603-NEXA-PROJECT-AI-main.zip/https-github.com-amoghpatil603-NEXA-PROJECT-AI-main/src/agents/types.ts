export enum AgentStatus {
    IDLE = 'IDLE',
    RUNNING = 'RUNNING',
    PAUSED = 'PAUSED',
    COMPLETED = 'COMPLETED',
    FAILED = 'FAILED',
    CANCELLED = 'CANCELLED'
}

export interface AgentCapabilities {
    canCode: boolean;
    canResearch: boolean;
    canPlan: boolean;
    canAnalyzeBusiness: boolean;
    canDesignElectronics: boolean;
}

export interface AgentTask {
    id: string;
    objective: string;
    contextId?: string;
    dependencies?: string[]; // IDs of tasks that must complete first
    startTime?: number;
    endTime?: number;
}

export interface AgentResult {
    taskId: string;
    success: boolean;
    output: any;
    error?: string;
}

export interface IAgent {
    id: string;
    name: string;
    status: AgentStatus;
    capabilities: AgentCapabilities;
    
    initialize(): Promise<void>;
    execute(task: AgentTask): Promise<AgentResult>;
    pause(): Promise<void>;
    resume(): Promise<void>;
    cancel(): Promise<void>;
    getStatus(): AgentStatus;
    getCapabilities(): AgentCapabilities;
}
