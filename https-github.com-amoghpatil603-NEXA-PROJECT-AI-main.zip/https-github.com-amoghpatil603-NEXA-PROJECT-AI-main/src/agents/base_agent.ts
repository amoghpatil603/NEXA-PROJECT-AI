import { IAgent, AgentStatus, AgentCapabilities, AgentTask, AgentResult } from './types';

export abstract class BaseAgent implements IAgent {
    public status: AgentStatus = AgentStatus.IDLE;
    protected isExecuting: boolean = false;
    
    constructor(
        public id: string,
        public name: string,
        public capabilities: AgentCapabilities
    ) {}

    async initialize(): Promise<void> {
        console.log(`[Agent:${this.name}] Initializing...`);
        this.status = AgentStatus.IDLE;
    }

    abstract execute(task: AgentTask): Promise<AgentResult>;

    async pause(): Promise<void> {
        if (this.status === AgentStatus.RUNNING) {
            console.log(`[Agent:${this.name}] Pausing...`);
            this.status = AgentStatus.PAUSED;
        }
    }

    async resume(): Promise<void> {
        if (this.status === AgentStatus.PAUSED) {
            console.log(`[Agent:${this.name}] Resuming...`);
            this.status = AgentStatus.RUNNING;
        }
    }

    async cancel(): Promise<void> {
        console.log(`[Agent:${this.name}] Cancelling...`);
        this.status = AgentStatus.CANCELLED;
    }

    getStatus(): AgentStatus {
        return this.status;
    }

    getCapabilities(): AgentCapabilities {
        return this.capabilities;
    }
}
