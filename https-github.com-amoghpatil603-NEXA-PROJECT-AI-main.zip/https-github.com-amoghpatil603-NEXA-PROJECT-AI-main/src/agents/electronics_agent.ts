import { BaseAgent } from './base_agent';
import { AgentTask, AgentResult, AgentStatus } from './types';
import { plannerEngine } from '../planner';
import { executionEngine } from '../execution';
import { Subsystem } from '../types';

export class ElectronicsAgent extends BaseAgent {
    constructor() {
        super('agent-electronics', 'Electronics Agent', {
            canCode: false,
            canResearch: true,
            canPlan: true,
            canAnalyzeBusiness: false,
            canDesignElectronics: true
        });
    }

    async execute(task: AgentTask): Promise<AgentResult> {
        if (this.isExecuting) {
            return {
                taskId: task.id,
                success: false,
                output: null,
                error: 'Recursion detected: Agent is already executing'
            };
        }
        this.isExecuting = true;
        this.status = AgentStatus.RUNNING;
        console.log(`[ElectronicsAgent] Designing electronics: ${task.objective}`);
        
        try {
            const plan = await plannerEngine.generatePlan(`Design electronics for: ${task.objective}`, Subsystem.TOOL_ENGINE);
            await executionEngine.executePlan(plan);
            const results = executionEngine.getExecutionHistory();
            const summary = results.map(r => `Task ${r.taskId}: ${r.output?.status || 'DONE'}`).join(', ');
            
            this.status = AgentStatus.COMPLETED;
            return {
                taskId: task.id,
                success: true,
                output: `Electronics design complete: ${summary}`
            };
        } catch (error: any) {
            this.status = AgentStatus.FAILED;
            return {
                taskId: task.id,
                success: false,
                output: null,
                error: error.message
            };
        } finally {
            this.isExecuting = false;
        }
    }
}
