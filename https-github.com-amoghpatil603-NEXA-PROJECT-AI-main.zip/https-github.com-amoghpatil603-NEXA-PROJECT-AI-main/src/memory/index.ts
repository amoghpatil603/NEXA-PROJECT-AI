import { MemoryService, MemoryStorage, MemoryCategory, Memory } from './memory_service';

export { MemoryCategory, type Memory };

export interface MemoryContext {
    relevantMemories: Memory[];
    formattedContext: string;
}

export class MemoryEngine {
    private storage: MemoryStorage;

    constructor(storage: MemoryStorage) {
        this.storage = storage;
    }

    /**
     * Determine whether the incoming message should be remembered, ignored, 
     * update existing, or delete existing memory.
     */
    async processInput(message: string, currentCategory: MemoryCategory = MemoryCategory.CONVERSATION): Promise<void> {
        const lower = message.toLowerCase();
        
        // Simple heuristic for memory operations
        // A robust implementation would use NLP or an LLM call here
        if (lower.includes('remember that') || lower.includes('my name is') || lower.includes('i like') || lower.includes('i prefer')) {
            console.log(`[MemoryEngine] Memory detected in input. Saving to ${currentCategory}...`);
            await this.storage.createMemory(currentCategory, message, { source: 'user_input', intent: 'remember' });
        } else if (lower.includes('forget that') || lower.includes('delete memory')) {
            console.log(`[MemoryEngine] Forget intent detected. Searching for matching memories...`);
            // E.g., user says "forget that my name is Alice"
            // We strip out the intent words and search
            const searchQuery = lower.replace('forget that', '').replace('delete memory', '').trim();
            if (searchQuery) {
                const results = await this.storage.searchMemory(searchQuery);
                for (const mem of results) {
                    await this.storage.deleteMemory(mem.id);
                    console.log(`[MemoryEngine] Deleted memory ID: ${mem.id}`);
                }
            }
        }
    }

    /**
     * Retrieve the most relevant memories for the given query.
     */
    async retrieveContext(query: string, limit: number = 5): Promise<MemoryContext> {
        console.log(`[MemoryEngine] Retrieving context for query: "${query}"`);
        const searchResults = await this.storage.searchMemory(query);
        
        // Return top N results
        const relevantMemories = searchResults.slice(0, limit);
        
        let formattedContext = '';
        if (relevantMemories.length > 0) {
            formattedContext = relevantMemories
                .map(m => `[${m.category}] ${m.content}`)
                .join('\n');
        }
        
        return {
            relevantMemories,
            formattedContext
        };
    }

    /**
     * Public interface to manually add memory
     */
    async addMemory(content: string, category: MemoryCategory = MemoryCategory.LONG_TERM, metadata?: any): Promise<number> {
        return this.storage.createMemory(category, content, metadata);
    }

    /**
     * Public interface to manually fetch all active memories
     */
    async getAllMemories(): Promise<Memory[]> {
        return this.storage.searchMemory('');
    }
}

// Export default singleton instance
export const memoryEngine = new MemoryEngine(new MemoryService());
