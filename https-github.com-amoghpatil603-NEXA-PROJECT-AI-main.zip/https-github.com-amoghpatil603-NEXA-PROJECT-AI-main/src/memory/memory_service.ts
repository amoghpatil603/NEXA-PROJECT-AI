export enum MemoryCategory {
    SESSION = 'SESSION',
    CONVERSATION = 'CONVERSATION',
    LONG_TERM = 'LONG_TERM',
    PROJECT = 'PROJECT',
    WORKING = 'WORKING',
    WORKSPACE = 'WORKSPACE'
}

export interface Memory {
    id: number;
    category: MemoryCategory;
    content: string;
    metadata: any;
    is_pinned: boolean;
    is_archived: boolean;
    created_at: string;
    updated_at: string;
}

export interface MemoryStorage {
    createMemory(category: MemoryCategory, content: string, metadata?: any): Promise<number>;
    getMemory(id: number): Promise<Memory | null>;
    updateMemory(id: number, content: string, metadata?: any): Promise<boolean>;
    deleteMemory(id: number): Promise<boolean>;
    searchMemory(query: string, category?: MemoryCategory): Promise<Memory[]>;
}

// Abstract/mock storage implementation
export class MemoryService implements MemoryStorage {
    private memories: Memory[] = [];
    private nextId = 1;

    async createMemory(category: MemoryCategory, content: string, metadata: any = {}): Promise<number> {
        console.log(`[MemoryStorage] Creating ${category} memory:`, content);
        const mem: Memory = {
            id: this.nextId++,
            category,
            content,
            metadata,
            is_pinned: false,
            is_archived: false,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };
        this.memories.push(mem);
        return mem.id;
    }

    async getMemory(id: number): Promise<Memory | null> {
        return this.memories.find(m => m.id === id) || null;
    }

    async updateMemory(id: number, content: string, metadata: any = {}): Promise<boolean> {
        const mem = await this.getMemory(id);
        if (!mem) return false;
        mem.content = content;
        mem.metadata = { ...mem.metadata, ...metadata };
        mem.updated_at = new Date().toISOString();
        return true;
    }

    async deleteMemory(id: number): Promise<boolean> {
        const initialLength = this.memories.length;
        this.memories = this.memories.filter(m => m.id !== id);
        return this.memories.length !== initialLength;
    }

    async searchMemory(query: string, category?: MemoryCategory): Promise<Memory[]> {
        // Very basic mock search heuristic
        const lowerQuery = query.toLowerCase();
        let results = this.memories.filter(m => !m.is_archived);
        if (category) {
            results = results.filter(m => m.category === category);
        }
        
        // Return everything for empty query, or keyword match
        if (query.trim() === '') return results;
        
        return results.filter(m => m.content.toLowerCase().includes(lowerQuery));
    }

    async pinMemory(id: number, isPinned: boolean = true): Promise<boolean> {
        const mem = await this.getMemory(id);
        if (!mem) return false;
        mem.is_pinned = isPinned;
        return true;
    }

    async archiveMemory(id: number, isArchived: boolean = true): Promise<boolean> {
        const mem = await this.getMemory(id);
        if (!mem) return false;
        mem.is_archived = isArchived;
        return true;
    }
}
