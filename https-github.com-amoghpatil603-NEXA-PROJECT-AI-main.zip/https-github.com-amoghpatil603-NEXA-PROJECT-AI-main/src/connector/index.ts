export interface GenerationParams {
  temperature?: number;
  top_k?: number;
  top_p?: number;
  max_tokens?: number;
}

export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface GenerateRequest {
  message: string;
  system_prompt?: string;
  history?: Message[];
  memory?: string;
  params?: GenerationParams;
}

export interface GenerateResponse {
  response: string;
  tokens_generated: number;
  time_taken: number;
  tokens_per_sec: number;
  error?: string;
}

export interface StreamChunk {
  chunk?: string;
  full?: string;
  tokens_count?: number;
  error?: string;
}

export class NexaConnector {
  private config: any = {};
  private isAvailable: boolean = false;

  async load_configuration(config: any): Promise<void> {
    this.config = config;
    console.log('[Connector] Configuration loaded', config);
  }

  async initialize(): Promise<boolean> {
    try {
      const status = await this.health_check();
      this.isAvailable = status.status === 'ok';
      console.log('[Connector] Initialized successfully. Model status:', status.status);
      return this.isAvailable;
    } catch (e) {
      console.error('[Connector] Initialization failed', e);
      this.isAvailable = false;
      return false;
    }
  }

  async health_check(timeoutMs = 5000): Promise<any> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch('/api/health', {
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!res.ok) throw new Error(`Health check failed: ${res.status}`);
      return await res.json();
    } catch (e) {
      clearTimeout(timeoutId);
      throw e;
    }
  }

  async generate(req: GenerateRequest, retries = 3): Promise<GenerateResponse> {
    let lastError;
    for (let i = 0; i < retries; i++) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 60000); // 60s timeout
        
        // Inject memory into the system prompt if provided
        let finalSystemPrompt = req.system_prompt || '';
        if (req.memory) {
          finalSystemPrompt = finalSystemPrompt ? `${finalSystemPrompt}\n\nUser Context:\n${req.memory}` : `User Context:\n${req.memory}`;
        }

        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: req.message,
            system_prompt: finalSystemPrompt,
            history: req.history,
            ...req.params
          }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        
        return await res.json();
      } catch (e: any) {
        console.warn(`[Connector] Generate attempt ${i + 1} failed:`, e);
        lastError = e;
        if (i < retries - 1) {
          await new Promise(r => setTimeout(r, 1000 * (i + 1))); // Exponential backoff
        }
      }
    }
    return {
      response: '',
      tokens_generated: 0,
      time_taken: 0,
      tokens_per_sec: 0,
      error: lastError?.message || 'Generation failed after retries'
    };
  }

  async *stream_generate(req: GenerateRequest, signal?: AbortSignal): AsyncGenerator<StreamChunk, void, unknown> {
    // Inject memory into the system prompt if provided
    let finalSystemPrompt = req.system_prompt || '';
    if (req.memory) {
      finalSystemPrompt = finalSystemPrompt ? `${finalSystemPrompt}\n\nUser Context:\n${req.memory}` : `User Context:\n${req.memory}`;
    }

    const res = await fetch('/api/chat/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: req.message,
        system_prompt: finalSystemPrompt,
        history: req.history,
        ...req.params
      }),
      signal
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    if (!res.body) throw new Error('No response body');

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.trim() === 'data: [DONE]') return;
          if (line.startsWith('data: ')) {
            const dataStr = line.slice(6).trim();
            if (dataStr) {
              try {
                yield JSON.parse(dataStr);
              } catch (e) {
                // Ignore parse errors on incomplete chunks
              }
            }
          }
        }
      }
    } finally {
      reader.releaseLock();
    }
  }
}

export const connector = new NexaConnector();
