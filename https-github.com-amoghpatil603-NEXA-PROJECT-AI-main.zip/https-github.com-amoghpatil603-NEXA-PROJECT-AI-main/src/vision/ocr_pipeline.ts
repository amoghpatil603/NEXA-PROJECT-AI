import { Image, OcrResult, DetectedObject } from './types';
import { toolEngine } from '../tools';

export class OcrPipeline {
    async extractText(image: Image): Promise<OcrResult> {
        // Integrate with existing OCR tool
        const res = await toolEngine.executeTool('tool-ocr', { imagePath: image.path });
        
        if (res.status === 'ERROR') {
            throw new Error(`OCR Failed: ${res.error}`);
        }
        
        // The OCR tool provides basic text and confidence.
        // We augment this with mock region mapping for layout support as specified.
        const regions: DetectedObject[] = [
            {
                label: 'text_block',
                confidence: res.data.confidence,
                bbox: { x: 10, y: 10, width: 200, height: 50 }
            }
        ];
        
        return {
            text: res.data.text || '',
            confidence: res.data.confidence || 0,
            regions
        };
    }
}
