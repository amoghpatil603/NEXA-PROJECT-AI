import { Image, ImageCaption } from './types';

export interface CaptioningModel {
    generateCaption(image: Image): Promise<ImageCaption>;
}

export class MockCaptioningModel implements CaptioningModel {
    async generateCaption(image: Image): Promise<ImageCaption> {
        return {
            text: "A generated caption describing the contents of the image in natural language.",
            confidence: 0.95
        };
    }
}

export class ImageCaptioner {
    constructor(private model: CaptioningModel) {}
    
    async describe(image: Image): Promise<ImageCaption> {
        return this.model.generateCaption(image);
    }
}
