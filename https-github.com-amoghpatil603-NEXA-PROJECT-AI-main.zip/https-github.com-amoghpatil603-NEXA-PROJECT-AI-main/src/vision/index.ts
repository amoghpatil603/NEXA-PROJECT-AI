import { ImageLoader } from './image_loader';
import { ImagePreprocessor } from './image_preprocessor';
import { MockObjectDetector, ObjectDetector } from './object_detector';
import { OcrPipeline } from './ocr_pipeline';
import { UIAnalyzer } from './ui_analyzer';
import { MockCaptioningModel, ImageCaptioner } from './captioning';
import { ImageAnalyzer } from './image_analyzer';
import { ScreenshotEngine } from './screenshot';

export * from './types';
export * from './image_loader';
export * from './image_preprocessor';
export * from './object_detector';
export * from './ocr_pipeline';
export * from './ui_analyzer';
export * from './captioning';
export * from './image_analyzer';
export * from './screenshot';

const loader = new ImageLoader();
const preprocessor = new ImagePreprocessor();
const objectDetectorModel = new MockObjectDetector();
const objectDetector = new ObjectDetector(objectDetectorModel);
const ocr = new OcrPipeline();
const uiAnalyzer = new UIAnalyzer(ocr, objectDetector);
const captioningModel = new MockCaptioningModel();
const captioner = new ImageCaptioner(captioningModel);

export const visionEngine = new ImageAnalyzer(
    loader,
    preprocessor,
    captioner,
    objectDetector,
    ocr,
    uiAnalyzer
);

export const screenshotEngine = new ScreenshotEngine(loader);
