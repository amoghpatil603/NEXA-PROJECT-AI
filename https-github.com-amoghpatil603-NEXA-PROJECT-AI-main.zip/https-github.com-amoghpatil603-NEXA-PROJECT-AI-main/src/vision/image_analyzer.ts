import { Image } from './types';
import { ImageCaptioner } from './captioning';
import { ObjectDetector } from './object_detector';
import { OcrPipeline } from './ocr_pipeline';
import { UIAnalyzer } from './ui_analyzer';
import { ImagePreprocessor, PreprocessOptions } from './image_preprocessor';
import { ImageLoader } from './image_loader';

export class ImageAnalyzer {
    constructor(
        private loader: ImageLoader,
        private preprocessor: ImagePreprocessor,
        private captioner: ImageCaptioner,
        private objectDetector: ObjectDetector,
        private ocr: OcrPipeline,
        private uiAnalyzer: UIAnalyzer
    ) {}

    async analyze(filePath: string, options?: PreprocessOptions): Promise<any> {
        let image = await this.loader.load(filePath);
        if (options) {
            image = await this.preprocessor.process(image, options);
        }
        
        const [caption, objects, text, ui] = await Promise.all([
            this.captioner.describe(image),
            this.objectDetector.analyze(image),
            this.ocr.extractText(image).catch(() => ({ text: '', confidence: 0, regions: [] })),
            this.uiAnalyzer.analyze(image)
        ]);

        return {
            imageMetadata: { id: image.id, format: image.format, width: image.width, height: image.height },
            caption,
            objects,
            text,
            ui
        };
    }
}
