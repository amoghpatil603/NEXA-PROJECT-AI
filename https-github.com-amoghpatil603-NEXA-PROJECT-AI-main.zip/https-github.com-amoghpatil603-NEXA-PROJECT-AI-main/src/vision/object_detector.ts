import { Image, DetectedObject } from './types';

export interface ObjectDetectionModel {
    detect(image: Image): Promise<DetectedObject[]>;
}

export class MockObjectDetector implements ObjectDetectionModel {
    async detect(image: Image): Promise<DetectedObject[]> {
        // This is a placeholder for a future local vision model
        return [
            {
                label: 'person',
                confidence: 0.98,
                bbox: { x: 50, y: 50, width: 100, height: 200 }
            },
            {
                label: 'car',
                confidence: 0.85,
                bbox: { x: 200, y: 150, width: 300, height: 100 }
            }
        ];
    }
}

export class ObjectDetector {
    constructor(private model: ObjectDetectionModel) {}

    async analyze(image: Image): Promise<DetectedObject[]> {
        return this.model.detect(image);
    }
}
