import { Image, UIAnalysisResult, UIElement, DetectedObject } from './types';
import { OcrPipeline } from './ocr_pipeline';
import { ObjectDetector } from './object_detector';

export class UIAnalyzer {
    constructor(
        private ocrPipeline: OcrPipeline,
        private objectDetector: ObjectDetector
    ) {}

    async analyze(image: Image): Promise<UIAnalysisResult> {
        // Run OCR to find text elements
        const ocr = await this.ocrPipeline.extractText(image).catch(() => ({ text: '', confidence: 0, regions: [] as DetectedObject[] }));
        
        // Run object detection to find shapes/buttons/windows
        const objects = await this.objectDetector.analyze(image);
        
        const elements: UIElement[] = [];
        
        // Map OCR regions to UI elements
        ocr.regions.forEach(region => {
            elements.push({
                type: 'text',
                bbox: region.bbox,
                text: ocr.text,
                confidence: region.confidence
            });
        });
        
        // Map Detected Objects to specific UI classes
        objects.forEach(obj => {
            let type: UIElement['type'] = 'unknown';
            if (['button', 'btn', 'submit'].includes(obj.label)) type = 'button';
            else if (['input', 'form', 'textarea'].includes(obj.label)) type = 'form';
            else if (['icon', 'svg', 'logo'].includes(obj.label)) type = 'icon';
            else if (['menu', 'nav', 'dropdown'].includes(obj.label)) type = 'menu';
            else if (['modal', 'dialog', 'popup'].includes(obj.label)) type = 'dialog';
            
            elements.push({
                type,
                bbox: obj.bbox,
                confidence: obj.confidence
            });
        });

        // Generate a mock summary
        const summary = `Detected ${elements.length} UI elements including ${elements.filter(e => e.type === 'button').length} buttons and ${elements.filter(e => e.type === 'form').length} forms.`;
        
        return { elements, summary };
    }
}
