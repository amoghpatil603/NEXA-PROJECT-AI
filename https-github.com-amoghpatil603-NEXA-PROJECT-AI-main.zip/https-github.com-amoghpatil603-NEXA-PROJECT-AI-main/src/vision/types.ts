export interface Image {
    id: string;
    path: string;
    format: 'png' | 'jpg' | 'jpeg' | 'webp' | 'bmp';
    width?: number;
    height?: number;
    sizeBytes?: number;
    data?: Buffer;
}

export interface BoundingBox {
    x: number;
    y: number;
    width: number;
    height: number;
}

export interface DetectedObject {
    label: string;
    confidence: number;
    bbox: BoundingBox;
}

export interface OcrResult {
    text: string;
    confidence: number;
    regions: DetectedObject[];
}

export interface UIElement {
    type: 'button' | 'form' | 'icon' | 'menu' | 'dialog' | 'text' | 'image' | 'unknown';
    bbox: BoundingBox;
    text?: string;
    confidence: number;
}

export interface UIAnalysisResult {
    elements: UIElement[];
    summary: string;
}

export interface ImageCaption {
    text: string;
    confidence: number;
}
