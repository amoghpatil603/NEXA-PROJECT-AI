import { AIProvider, ContextEngine } from "./types";
import { GeminiProvider } from "./providers/gemini";
import { ProductionContextEngine } from "./context_engine";

export class ProviderManager {
  private static instance: ProviderManager;
  private provider: AIProvider;
  private contextEngine: ContextEngine;

  private constructor() {
    // For now, default to Gemini
    this.provider = new GeminiProvider();
    this.contextEngine = new ProductionContextEngine();
  }

  static getInstance(): ProviderManager {
    if (!ProviderManager.instance) {
      ProviderManager.instance = new ProviderManager();
    }
    return ProviderManager.instance;
  }

  getProvider(): AIProvider {
    return this.provider;
  }

  getContextEngine(): ContextEngine {
    return this.contextEngine;
  }
}
