import { GoogleGenAI } from "@google/genai";
import { AIProvider } from "../types";

export class GeminiProvider implements AIProvider {
  private ai: GoogleGenAI | null = null;
  private modelName = 'gemini-2.0-flash';

  async initialize(): Promise<void> {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error('GEMINI_API_KEY environment variable is required');
    }
    this.ai = new GoogleGenAI({ apiKey: key });
  }

  private prepareContents(message: string, history?: any[]) {
    const contents = history ? history.map((m: any) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    })) : [];
    contents.push({ role: 'user', parts: [{ text: message }] });
    return contents;
  }

  private async withRetry<T>(fn: () => Promise<T>, retries = 5, delay = 5000): Promise<T> {
    try {
      return await fn();
    } catch (error: any) {
      if (error?.code === 429 && retries > 0) {
        console.warn(`Rate limit hit. Retrying in ${delay}ms... (${retries} retries left)`);
        await new Promise(resolve => setTimeout(resolve, delay));
        return this.withRetry(fn, retries - 1, delay * 2);
      }
      throw error;
    }
  }

  async generate(message: string, system_prompt?: string, history?: any[], options?: any): Promise<{ text: string; tokens: number }> {
    if (!this.ai) await this.initialize();
    
    return this.withRetry(async () => {
      const response = await this.ai!.models.generateContent({
        model: this.modelName,
        contents: this.prepareContents(message, history),
        config: {
          systemInstruction: system_prompt,
          temperature: options?.temperature,
          topK: options?.top_k,
          topP: options?.top_p,
          maxOutputTokens: options?.max_tokens,
        }
      });

      const responseText = response.text || "";
      const tokensCount = responseText.split(' ').length; // Rough estimate
      
      return { text: responseText, tokens: tokensCount };
    });
  }

  async *generateStream(message: string, system_prompt?: string, history?: any[], options?: any): AsyncIterable<{ chunk: string; full: string; tokens: number }> {
    if (!this.ai) await this.initialize();

    const stream = await this.ai!.models.generateContentStream({
      model: this.modelName,
      contents: this.prepareContents(message, history),
      config: {
        systemInstruction: system_prompt,
        temperature: options?.temperature,
        topK: options?.top_k,
        topP: options?.top_p,
        maxOutputTokens: options?.max_tokens,
      }
    });

    let fullText = "";
    let tokensCount = 0;
    for await (const chunk of stream) {
      fullText += chunk.text;
      tokensCount += (chunk.text.split(' ').length || 1);
      yield { chunk: chunk.text || "", full: fullText, tokens: tokensCount };
    }
  }
}
