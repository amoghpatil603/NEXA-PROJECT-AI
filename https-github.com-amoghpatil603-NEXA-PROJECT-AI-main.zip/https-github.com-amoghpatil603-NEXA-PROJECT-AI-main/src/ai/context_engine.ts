import { ContextEngine } from "./types";
import { memoryEngine } from "../memory";
import { knowledgeEngine } from "../rag";

export class ProductionContextEngine implements ContextEngine {
  async buildPrompt(
    userMessage: string,
    systemPrompt: string = "You are a helpful assistant.",
    history: any[] = [],
    options: { maxTokens?: number } = {}
  ): Promise<{ prompt: string; systemPrompt: string }> {
    
    // 1. Retrieve relevant memories
    const memoryContext = await memoryEngine.retrieveContext(userMessage);

    // 2. Retrieve relevant RAG context
    const ragResults = await knowledgeEngine.query(userMessage);
    const ragContext = ragResults.map(r => r.chunk.text).join("\n");

    // 3. Assemble prompt
    let prompt = `System Prompt: ${systemPrompt}\n\n`;
    
    if (memoryContext.formattedContext) {
        prompt += `Relevant Memories:\n${memoryContext.formattedContext}\n\n`;
    }
    
    if (ragContext) {
        prompt += `Relevant Knowledge:\n${ragContext}\n\n`;
    }
    
    prompt += `Conversation History:\n${history.map(h => `${h.role}: ${h.content}`).join("\n")}\n\n`;
    prompt += `User: ${userMessage}`;

    return { prompt, systemPrompt };
  }
}
