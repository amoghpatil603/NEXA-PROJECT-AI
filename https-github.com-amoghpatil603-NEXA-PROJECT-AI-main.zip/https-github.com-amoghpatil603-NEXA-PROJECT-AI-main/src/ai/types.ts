export interface AIProvider {
  initialize(): Promise<void>;
  generate(message: string, system_prompt?: string, history?: any[], options?: any): Promise<{ text: string; tokens: number }>;
  generateStream(message: string, system_prompt?: string, history?: any[], options?: any): AsyncIterable<{ chunk: string; full: string; tokens: number }>;
}

export interface ContextEngine {
  buildPrompt(
    userMessage: string,
    systemPrompt?: string,
    history?: any[],
    options?: { maxTokens?: number }
  ): Promise<{ prompt: string; systemPrompt: string }>;
}
