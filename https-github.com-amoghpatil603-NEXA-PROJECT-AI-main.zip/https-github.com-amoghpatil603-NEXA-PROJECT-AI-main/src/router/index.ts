import { connector, GenerateRequest, Message } from '../connector';
import { memoryEngine, MemoryCategory } from '../memory';
import { plannerEngine } from '../planner';
import { executionEngine } from '../execution';
import { knowledgeEngine } from '../rag';
import { toolEngine } from '../tools';
import { visionEngine } from '../vision';
import { voiceEngine } from '../voice';
import { desktopEngine } from '../desktop';
import { autonomyManager } from '../autonomy';
import { Subsystem } from '../types';

export interface RouterContext {
  originalMessage: string;
  history: Message[];
  systemPrompt?: string;
  
  // Pipeline state
  memoryContext?: string;
  ragContext?: string;
  toolResults?: any[];
  visionContext?: string;
  voiceContext?: string;
  desktopContext?: string;
  agentContext?: string;
  plannerContext?: string;
  
  routingPath: Subsystem[];
}

export class NexaRouter {
  
  /**
   * Analyzes the incoming request to determine which subsystems need to be involved.
   * This uses heuristics and keyword matching for fast routing, but could be backed
   * by an LLM call via the connector for complex intents.
   */
  async determineRouting(message: string): Promise<Subsystem[]> {
    const route: Subsystem[] = [];
    const lower = message.toLowerCase();
    
    // Always trigger memory processing to capture context and evaluate updates
    route.push(Subsystem.MEMORY);

    // 1. Voice processing
    if (
        lower.includes('voice') || 
        lower.includes('speak') || 
        lower.includes('listen') || 
        lower.includes('start voice chat') || 
        lower.includes('read aloud')
    ) {
      route.push(Subsystem.VOICE);
    }
    
    // 2. Vision processing
    if (
        lower.includes('image') || 
        lower.includes('look at') || 
        lower.includes('picture') ||
        lower.includes('screenshot') ||
        lower.includes('screen') ||
        lower.includes('ui')
    ) {
      route.push(Subsystem.VISION);
    }
    
    // 3. RAG / Document Retrieval
    if (lower.includes('file') || lower.includes('document') || lower.includes('search') || lower.includes('read')) {
      route.push(Subsystem.RAG);
    }
    
    // 4. Desktop processing
    if (
        lower.includes('open') || 
        lower.includes('close') || 
        lower.includes('click') || 
        lower.includes('type') || 
        lower.includes('launch') || 
        lower.includes('screenshot') || 
        lower.includes('desktop') || 
        lower.includes('window') || 
        lower.includes('mouse') || 
        lower.includes('keyboard') || 
        lower.includes('clipboard')
    ) {
      route.push(Subsystem.DESKTOP);
    }
    
    // 5. Agent processing
    if (
        lower.includes('research') || 
        lower.includes('code') || 
        lower.includes('plan') || 
        lower.includes('business') || 
        lower.includes('electronics') || 
        lower.includes('agent')
    ) {
      route.push(Subsystem.AGENTS);
    }
    
    // 6. Autonomy processing
    if (
        lower.includes('complete this project') ||
        lower.includes('research this topic') ||
        lower.includes('build this application') ||
        lower.includes('solve this problem') ||
        lower.includes('continue')
    ) {
      route.push(Subsystem.AUTONOMY);
    }
    
    // 7. Planner (Always plan execution)
    route.push(Subsystem.PLANNER);
    
    // Always end with normal conversational processing
    route.push(Subsystem.NORMAL);
    
    return route;
  }

  /**
   * Executes the multi-stage routing pipeline.
   * Each subsystem augments the context before finally calling the connector.
   */
  async routeRequest(request: GenerateRequest, onChunk?: (chunk: string) => void): Promise<string> {
    const route = await this.determineRouting(request.message);
    console.log(`[Router] Determined routing path: ${route.join(' -> ')}`);
    
    const context: RouterContext = {
      originalMessage: request.message,
      history: request.history || [],
      systemPrompt: request.system_prompt,
      routingPath: route
    };
    
    // Process each stage in the routing path
    for (const subsystem of route) {
        if (subsystem === Subsystem.RAG) continue; // Handled by ExecutionEngine
        await this.processSubsystem(subsystem, context);
    }
    
    // Build final request for the Connector
    const finalRequest = this.buildConnectorRequest(context);
    
    // Execute via Connector
    if (onChunk) {
        let finalResult = "";
        const stream = connector.stream_generate(finalRequest);
        for await (const chunk of stream) {
            if (chunk.chunk) onChunk(chunk.chunk);
            if (chunk.full) finalResult = chunk.full;
        }
        return finalResult;
    } else {
        const result = await connector.generate(finalRequest);
        return result.response;
    }
  }

  private async processSubsystem(subsystem: Subsystem, context: RouterContext) {
    switch (subsystem) {
      case Subsystem.MEMORY:
        console.log(`[Router] Executing MEMORY subsystem...`);
        // Let memory engine process input for storage/updates
        await memoryEngine.processInput(context.originalMessage, MemoryCategory.CONVERSATION);
        // Retrieve relevant context to augment prompt
        const memData = await memoryEngine.retrieveContext(context.originalMessage);
        if (memData.formattedContext) {
            context.memoryContext = memData.formattedContext;
        }
        break;
      case Subsystem.PLANNER:
        console.log(`[Router] Executing PLANNER subsystem...`);
        // Determine preferred subsystem if RAG detected
        const preferred = context.routingPath.includes(Subsystem.RAG) ? Subsystem.RAG : undefined;
        const plan = await plannerEngine.generatePlan(context.originalMessage, preferred);
        
        console.log(`[Router] Executing PLANNER generated plan with ExecutionEngine...`);
        await executionEngine.executePlan(plan);
        const execStatus = executionEngine.getExecutionStatus();
        
        // Pass intermediate outputs into context
        const outputs = Object.values(execStatus.intermediateOutputs);
        if (outputs.length > 0) {
            const toolOuts = outputs.filter(o => !o.isRag && !o.isVision && !o.isVoice && !o.isDesktop && !o.isAgent);
            const ragOuts = outputs.filter(o => o.isRag);
            const visionOuts = outputs.filter(o => o.isVision);
            const voiceOuts = outputs.filter(o => o.isVoice);
            const desktopOuts = outputs.filter(o => o.isDesktop);
            const agentOuts = outputs.filter(o => o.isAgent);
            
            if (toolOuts.length > 0) {
                context.toolResults = toolOuts;
            }
            if (ragOuts.length > 0) {
                // Flatten the results
                const chunks = [];
                for (const o of ragOuts) {
                    if (o.data && Array.isArray(o.data)) {
                        chunks.push(...o.data);
                    }
                }
                if (chunks.length > 0) {
                    context.ragContext = chunks.map(r => r.chunk?.text).filter(Boolean).join('\n\n');
                }
            }
            if (visionOuts.length > 0) {
                context.visionContext = visionOuts.map(o => JSON.stringify(o.data)).join('\n\n');
            }
            if (voiceOuts.length > 0) {
                context.voiceContext = voiceOuts.map(o => JSON.stringify(o.data)).join('\n\n');
            }
            if (desktopOuts.length > 0) {
                context.desktopContext = desktopOuts.map(o => JSON.stringify(o.data)).join('\n\n');
            }
            if (agentOuts.length > 0) {
                context.agentContext = agentOuts.map(o => JSON.stringify(o.data)).join('\n\n');
            }
        }

        context.plannerContext = `Execution Plan Generated (ID: ${plan.id}, Type: ${plan.type}):\n` + 
            plan.tasks.map(t => `- Task [${t.id}]: ${t.description} (Subsystem: ${t.requiredSubsystem})`).join('\n') +
            `\n\nExecution completed with status: ${execStatus.engineState}`;
        break;
      case Subsystem.TOOL_ENGINE:
        // Delegate to Tool Engine (to be integrated)
        console.log(`[Router] Executing TOOL_ENGINE subsystem...`);
        break;
      case Subsystem.VISION:
        // Delegate to Vision module (to be integrated)
        console.log(`[Router] Executing VISION subsystem...`);
        break;
      case Subsystem.VOICE:
        // Delegate to Voice module (to be integrated)
        console.log(`[Router] Executing VOICE subsystem...`);
        break;
      case Subsystem.DESKTOP:
        // Delegate to Desktop module
        console.log(`[Router] Executing DESKTOP subsystem...`);
        break;
      case Subsystem.AGENTS:
        // Delegate to Agent module
        console.log(`[Router] Executing AGENTS subsystem...`);
        break;
      case Subsystem.AUTONOMY:
        // Delegate to Autonomy module
        console.log(`[Router] Executing AUTONOMY subsystem...`);
        await autonomyManager.startGoal(context.originalMessage);
        break;
      case Subsystem.NORMAL:
        // Final conversational synthesis stage
        console.log(`[Router] Reached NORMAL conversational subsystem.`);
        break;
    }
  }

  private summarizeHistory(history: Message[]): Message[] {
    if (history.length <= 10) return history;
    const summary = `[System: Conversation summary - ${history.length - 5} earlier turns summarized to maintain context]`
    return [
      { role: 'system', content: summary },
      ...history.slice(-5)
    ];
  }

  private buildConnectorRequest(context: RouterContext): GenerateRequest {
    const systemPrompt = context.systemPrompt || "You are NEXA, an AI assistant.";
    
    // Structured prompt construction with basic truncation/prioritization
    const sections: string[] = [];
    if (context.memoryContext) sections.push(`[Memory]:\n${context.memoryContext}`);
    if (context.ragContext) sections.push(`[Knowledge]:\n${context.ragContext}`);
    if (context.toolResults && context.toolResults.length > 0) sections.push(`[Tools]:\n${this.safeStringify(context.toolResults)}`);
    if (context.plannerContext) sections.push(`[Plan]:\n${context.plannerContext}`);
    if (context.visionContext) sections.push(`[Vision]:\n${context.visionContext}`);
    if (context.voiceContext) sections.push(`[Voice]:\n${context.voiceContext}`);
    if (context.desktopContext) sections.push(`[Desktop]:\n${context.desktopContext}`);
    if (context.agentContext) sections.push(`[Agents]:\n${context.agentContext}`);

    const finalPrompt = `${systemPrompt}\n\n${sections.join('\n\n')}`;
    
    return {
      message: context.originalMessage,
      system_prompt: finalPrompt,
      history: this.summarizeHistory(context.history),
    };
  }

  private safeStringify(obj: any): string {
    const cache = new Set();
    return JSON.stringify(obj, (key, value) => {
        if (typeof value === 'object' && value !== null) {
            if (cache.has(value)) {
                return '[Circular]';
            }
            cache.add(value);
        }
        return value;
    }, 2);
  }
}

export const router = new NexaRouter();
