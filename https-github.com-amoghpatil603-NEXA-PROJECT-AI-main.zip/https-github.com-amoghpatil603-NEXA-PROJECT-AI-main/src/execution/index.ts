import { ExecutionPlan, PlannerTask, TaskStatus } from '../planner';
import { toolEngine } from '../tools';

export enum EngineState {
    IDLE = 'IDLE',
    RUNNING = 'RUNNING',
    PAUSED = 'PAUSED',
    CANCELLED = 'CANCELLED'
}

export interface TaskResult {
    taskId: string;
    output: any;
    error?: string;
    timestamp: number;
}

export interface ExecutionContext {
    planId: string;
    engineState: EngineState;
    currentTaskId?: string;
    completedTasks: string[];
    failedTasks: string[];
    skippedTasks: string[];
    executionHistory: TaskResult[];
    intermediateOutputs: Record<string, any>;
    startTime?: number;
    endTime?: number;
}

export class ExecutionEngine {
    private currentPlan: ExecutionPlan | null = null;
    private context: ExecutionContext = this.createEmptyContext('');
    private tasks: Map<string, PlannerTask> = new Map();

    private createEmptyContext(planId: string): ExecutionContext {
        return {
            planId,
            engineState: EngineState.IDLE,
            completedTasks: [],
            failedTasks: [],
            skippedTasks: [],
            executionHistory: [],
            intermediateOutputs: {}
        };
    }

    public async executePlan(plan: ExecutionPlan): Promise<void> {
        this.currentPlan = plan;
        this.context = this.createEmptyContext(plan.id);
        this.context.startTime = Date.now();
        this.context.engineState = EngineState.RUNNING;
        
        this.tasks.clear();
        for (const task of plan.tasks) {
            this.tasks.set(task.id, { ...task, status: TaskStatus.PENDING });
        }

        console.log(`[ExecutionEngine] Starting execution of plan: ${plan.id}`);
        await this.runLoop();
    }

    public pauseExecution(): void {
        if (this.context.engineState === EngineState.RUNNING) {
            console.log(`[ExecutionEngine] Pausing execution`);
            this.context.engineState = EngineState.PAUSED;
        }
    }

    public resumeExecution(): void {
        if (this.context.engineState === EngineState.PAUSED) {
            console.log(`[ExecutionEngine] Resuming execution`);
            this.context.engineState = EngineState.RUNNING;
            this.runLoop();
        }
    }

    public cancelExecution(): void {
        if (this.context.engineState === EngineState.RUNNING || this.context.engineState === EngineState.PAUSED) {
            console.log(`[ExecutionEngine] Cancelling execution`);
            this.context.engineState = EngineState.CANCELLED;
            
            // Mark remaining tasks as cancelled
            for (const [id, task] of this.tasks.entries()) {
                if (task.status === TaskStatus.PENDING || task.status === TaskStatus.READY) {
                    task.status = TaskStatus.CANCELLED;
                }
            }
        }
    }

    public async retryTask(taskId: string): Promise<void> {
        const task = this.tasks.get(taskId);
        if (!task) throw new Error(`Task ${taskId} not found`);
        if (task.status !== TaskStatus.FAILED) throw new Error(`Task ${taskId} is not in FAILED state`);
        
        console.log(`[ExecutionEngine] Retrying task: ${taskId}`);
        task.status = TaskStatus.PENDING;
        
        if (this.context.engineState !== EngineState.RUNNING) {
            this.resumeExecution();
        }
    }

    public getExecutionStatus(): ExecutionContext {
        return this.context;
    }

    public getExecutionHistory(): TaskResult[] {
        return this.context.executionHistory;
    }

    private async runLoop(): Promise<void> {
        while (this.context.engineState === EngineState.RUNNING) {
            const nextTask = this.getNextReadyTask();
            
            if (!nextTask) {
                // Check if we are totally done or deadlocked
                const allDone = Array.from(this.tasks.values()).every(
                    t => t.status === TaskStatus.COMPLETED || t.status === TaskStatus.SKIPPED || t.status === TaskStatus.CANCELLED || t.status === TaskStatus.FAILED
                );
                
                if (allDone) {
                    this.context.engineState = EngineState.IDLE;
                    this.context.endTime = Date.now();
                    console.log(`[ExecutionEngine] Plan execution finished`);
                } else {
                    // This could be waiting on async operations, but for now we'll break
                    // In a fully async system, completion events would re-trigger runLoop
                    console.log(`[ExecutionEngine] No tasks ready, pausing run loop`);
                    this.context.engineState = EngineState.IDLE;
                }
                break;
            }

            await this.executeTask(nextTask);
        }
    }

    private getNextReadyTask(): PlannerTask | null {
        for (const task of this.tasks.values()) {
            if (task.status === TaskStatus.PENDING) {
                // Check dependencies
                const depsMet = task.dependencies.every(depId => {
                    const dep = this.tasks.get(depId);
                    return dep && dep.status === TaskStatus.COMPLETED;
                });
                
                if (depsMet) {
                    task.status = TaskStatus.READY;
                    return task;
                }
            } else if (task.status === TaskStatus.READY) {
                return task;
            }
        }
        return null;
    }

    private async executeTask(task: PlannerTask): Promise<void> {
        console.log(`[ExecutionEngine] Executing task [${task.id}]: ${task.description}`);
        this.context.currentTaskId = task.id;
        task.status = TaskStatus.RUNNING;
        
        try {
            // Mock execution delay
            await new Promise(resolve => setTimeout(resolve, 500));
            
            let output: any;
            
            if (task.requiredSubsystem === 'TOOL_ENGINE') {
                const anyTask = task as any;
                if (anyTask.toolId && anyTask.toolInput) {
                    console.log(`[ExecutionEngine] Passing to ToolEngine -> ${anyTask.toolId}`);
                    output = await toolEngine.executeTool(anyTask.toolId, anyTask.toolInput);
                } else {
                    const isCalc = this.currentPlan?.goal.toLowerCase().includes('calculate');
                    if (isCalc) {
                        const expression = this.currentPlan?.goal.replace(/calculate/i, '').trim();
                        console.log(`[ExecutionEngine] Passing to ToolEngine -> CalculatorTool with expression: "${expression}"`);
                        output = await toolEngine.executeTool('tool-calculator', { expression });
                    } else {
                        output = { error: "No tool implemented for this intent." };
                    }
                }
            } else if (task.requiredSubsystem === 'RAG') {
                console.log(`[ExecutionEngine] Passing to KnowledgeEngine (RAG) for query: "${this.currentPlan?.goal}"`);
                const { knowledgeEngine } = await import('../rag');
                
                // Block fix: Check if goal references a file and add to index
                const goal = this.currentPlan?.goal || "";
                if (goal.includes('.md')) {
                    const filename = goal.split(' ').find(word => word.endsWith('.md'));
                    if (filename) {
                        try {
                            await knowledgeEngine.addDocument(filename);
                            console.log(`[ExecutionEngine] Indexed file: ${filename}`);
                        } catch (e) {
                            console.error(`[ExecutionEngine] Failed to index ${filename}:`, e);
                        }
                    }
                }
                
                const results = await knowledgeEngine.query(goal, 3);
                output = { status: 'SUCCESS', data: results, isRag: true };
            } else if (task.requiredSubsystem === 'VISION') {
                console.log(`[ExecutionEngine] Passing to VisionEngine`);
                const { visionEngine, screenshotEngine } = await import('../vision');
                
                // Very basic mock heuristic to test logic:
                if (this.currentPlan?.goal.toLowerCase().includes('screenshot') || this.currentPlan?.goal.toLowerCase().includes('screen')) {
                    const screenshot = await screenshotEngine.capture();
                    const analysis = await visionEngine.analyze(screenshot.path);
                    output = { status: 'SUCCESS', data: analysis, isVision: true };
                } else {
                    // Just analyze a mock file for standard vision analysis
                    const analysis = await visionEngine.analyze('/tmp/mock_image.png');
                    output = { status: 'SUCCESS', data: analysis, isVision: true };
                }
            } else if (task.requiredSubsystem === 'VOICE') {
                console.log(`[ExecutionEngine] Passing to VoiceEngine`);
                const { voiceEngine } = await import('../voice');
                const goal = this.currentPlan?.goal.toLowerCase() || "";
                
                if (goal.includes('listen') || goal.includes('voice chat')) {
                    const transcript = await voiceEngine.listen();
                    output = { status: 'SUCCESS', data: transcript, isVoice: true };
                } else if (goal.includes('speak') || goal.includes('read aloud')) {
                    await voiceEngine.speak("This is a synthesized voice response.");
                    output = { status: 'SUCCESS', data: { spoken: true }, isVoice: true };
                } else {
                    const transcript = await voiceEngine.listen();
                    output = { status: 'SUCCESS', data: transcript, isVoice: true };
                }
            } else if (task.requiredSubsystem === 'DESKTOP') {
                console.log(`[ExecutionEngine] Passing to DesktopEngine`);
                const { desktopEngine } = await import('../desktop');
                const goal = this.currentPlan?.goal.toLowerCase() || "";
                
                // Route to appropriate desktop action based on goal
                let action: any;
                if (goal.includes('screenshot')) {
                    action = { type: 'screen', action: 'screenshot' };
                } else if (goal.includes('click')) {
                    action = { type: 'mouse', action: 'click' };
                } else if (goal.includes('type')) {
                    action = { type: 'keyboard', action: 'type', params: { text: 'Hello from NEXA' } };
                } else if (goal.includes('window')) {
                    action = { type: 'window', action: 'list' };
                } else if (goal.includes('open') || goal.includes('launch')) {
                    action = { type: 'application', action: 'launch', params: { path: 'notepad.exe' } };
                } else {
                    action = { type: 'window', action: 'focused' };
                }
                
                const res = await desktopEngine.execute(action);
                output = { status: 'SUCCESS', data: res, isDesktop: true };
            } else if (task.requiredSubsystem === 'AGENTS') {
                console.log(`[ExecutionEngine] Passing to AgentsEngine`);
                const { agentsEngine } = await import('../agents');
                const goal = this.currentPlan?.goal.toLowerCase() || "";
                
                let agentId = 'agent-planning';
                if (goal.includes('code')) agentId = 'agent-coding';
                else if (goal.includes('research')) agentId = 'agent-research';
                else if (goal.includes('business')) agentId = 'agent-business';
                else if (goal.includes('electronics')) agentId = 'agent-electronics';
                
                const res = await agentsEngine.executeAgent(agentId, {
                    id: `task_${Date.now()}`,
                    objective: this.currentPlan?.goal || ""
                });
                output = { status: 'SUCCESS', data: res, isAgent: true };
            } else {
                output = { simulated: true, outputFor: task.id };
            }
            
            task.status = TaskStatus.COMPLETED;
            this.context.completedTasks.push(task.id);
            this.context.intermediateOutputs[task.id] = output;
            
            this.context.executionHistory.push({
                taskId: task.id,
                output: output,
                timestamp: Date.now()
            });
            console.log(`[ExecutionEngine] Task [${task.id}] COMPLETED`);
            
        } catch (error: any) {
            console.error(`[ExecutionEngine] Task [${task.id}] FAILED: ${error.message}`);
            task.status = TaskStatus.FAILED;
            this.context.failedTasks.push(task.id);
            
            this.context.executionHistory.push({
                taskId: task.id,
                output: null,
                error: error.message,
                timestamp: Date.now()
            });
            
            // If a task fails, we might pause execution to allow intervention or retry
            this.pauseExecution();
        } finally {
            if (this.context.currentTaskId === task.id) {
                this.context.currentTaskId = undefined;
            }
        }
    }
}

export const executionEngine = new ExecutionEngine();
