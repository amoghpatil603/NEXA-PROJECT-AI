export class Cache<T> {
    private store: Map<string, { value: T, expiry: number }> = new Map();

    set(key: string, value: T, ttlMs: number): void {
        this.store.set(key, { value, expiry: Date.now() + ttlMs });
    }

    get(key: string): T | undefined {
        const item = this.store.get(key);
        if (!item) return undefined;
        if (Date.now() > item.expiry) {
            this.store.delete(key);
            return undefined;
        }
        return item.value;
    }
    
    invalidate(key: string): void {
        this.store.delete(key);
    }
    
    clear(): void {
        this.store.clear();
    }
}
