export interface EmbeddingModel {
    embed(text: string): Promise<number[]>;
    embedBatch(texts: string[]): Promise<number[][]>;
}

export class MockEmbeddingModel implements EmbeddingModel {
    async embed(text: string): Promise<number[]> {
        // Return a mock normalized vector
        const vec = Array.from({ length: 128 }, () => Math.random() - 0.5);
        const norm = Math.sqrt(vec.reduce((sum, val) => sum + val * val, 0));
        return vec.map(v => v / (norm || 1));
    }
    
    async embedBatch(texts: string[]): Promise<number[][]> {
        return Promise.all(texts.map(t => this.embed(t)));
    }
}
