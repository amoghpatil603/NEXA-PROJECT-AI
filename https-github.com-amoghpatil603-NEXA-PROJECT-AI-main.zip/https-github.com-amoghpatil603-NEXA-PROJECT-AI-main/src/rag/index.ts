import { KnowledgeManager } from './knowledge_manager';
import { DocumentLoader } from './document_loader';
import { DocumentChunker } from './chunker';
import { MockEmbeddingModel } from './embeddings';
import { InMemoryVectorStore } from './vector_store';
import { Ranker } from './ranking';
import { Retriever } from './retriever';

export * from './types';
export * from './chunker';
export * from './embeddings';
export * from './vector_store';
export * from './ranking';
export * from './retriever';
export * from './document_loader';
export * from './cache';
export * from './knowledge_manager';

const docLoader = new DocumentLoader();
const chunker = new DocumentChunker({ chunkSize: 1000, chunkOverlap: 100, strategy: 'fixed' });
const embedder = new MockEmbeddingModel();
const vectorStore = new InMemoryVectorStore();
const ranker = new Ranker({ recencyBoost: 0.1 });
const retriever = new Retriever(vectorStore, embedder, ranker);

export const knowledgeEngine = new KnowledgeManager(
    docLoader,
    chunker,
    embedder,
    vectorStore,
    retriever
);
