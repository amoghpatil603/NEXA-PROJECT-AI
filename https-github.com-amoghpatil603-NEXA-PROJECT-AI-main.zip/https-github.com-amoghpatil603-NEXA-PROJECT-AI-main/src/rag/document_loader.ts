import { Document } from './types';
import { toolEngine } from '../tools';

export class DocumentLoader {
    async load(filePath: string): Promise<Document> {
        let text = "";
        let metadata: Record<string, any> = { source: filePath, timestamp: Date.now() };
        
        try {
            if (filePath.endsWith('.pdf')) {
                const res = await toolEngine.executeTool('tool-pdf', { path: filePath });
                if (res.status === 'ERROR') throw new Error(res.error);
                text = res.data.text;
                metadata = { ...metadata, ...res.data.metadata };
            } else if (filePath.match(/\.(png|jpe?g|webp)$/i)) {
                const res = await toolEngine.executeTool('tool-ocr', { imagePath: filePath });
                if (res.status === 'ERROR') throw new Error(res.error);
                text = res.data.text;
                metadata.confidence = res.data.confidence;
            } else {
                const res = await toolEngine.executeTool('tool-filesystem', { action: 'read_file', path: filePath });
                if (res.status === 'ERROR') throw new Error(res.error);
                text = res.data;
            }
        } catch (error: any) {
            throw new Error(`Failed to load document ${filePath}: ${error.message}`);
        }

        return {
            id: `doc_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
            text,
            metadata
        };
    }
}
