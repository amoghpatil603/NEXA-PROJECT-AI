import { Document, Chunk } from './types';

export interface ChunkingOptions {
    chunkSize: number;
    chunkOverlap: number;
    strategy: 'fixed' | 'paragraph' | 'sentence';
}

export class DocumentChunker {
    constructor(private options: ChunkingOptions) {}

    chunk(doc: Document): Chunk[] {
        const chunks: Chunk[] = [];
        let start = 0;
        let index = 0;
        
        // Very basic chunking - production would be more sophisticated
        while (start < doc.text.length) {
            let end = start + this.options.chunkSize;
            
            if (this.options.strategy === 'paragraph') {
                const nextNewline = doc.text.indexOf('\n\n', end - this.options.chunkOverlap);
                if (nextNewline !== -1 && nextNewline < end + this.options.chunkOverlap) {
                    end = nextNewline + 2;
                }
            } else if (this.options.strategy === 'sentence') {
                const nextPeriod = doc.text.indexOf('.', end - this.options.chunkOverlap);
                if (nextPeriod !== -1 && nextPeriod < end + this.options.chunkOverlap) {
                    end = nextPeriod + 1;
                }
            }

            const textChunk = doc.text.substring(start, end);
            chunks.push({
                id: `${doc.id}-chunk-${index++}`,
                documentId: doc.id,
                text: textChunk,
                metadata: { ...doc.metadata, chunkIndex: index - 1 }
            });
            start = end - this.options.chunkOverlap;
            if (start >= doc.text.length || start < 0) break; // sanity check
        }
        return chunks;
    }
}
