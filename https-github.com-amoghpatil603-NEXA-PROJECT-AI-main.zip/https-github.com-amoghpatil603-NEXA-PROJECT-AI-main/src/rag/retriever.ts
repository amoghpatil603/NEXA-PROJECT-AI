import { VectorStore } from './vector_store';
import { EmbeddingModel } from './embeddings';
import { Ranker } from './ranking';
import { SearchResult } from './types';
import { Cache } from './cache';

export class Retriever {
    private searchCache = new Cache<SearchResult[]>();

    constructor(
        private vectorStore: VectorStore,
        private embeddingModel: EmbeddingModel,
        private ranker: Ranker
    ) {}

    async retrieve(query: string, topK: number = 5, filter?: Record<string, any>): Promise<SearchResult[]> {
        const cacheKey = `${query}_${topK}_${JSON.stringify(filter || {})}`;
        const cached = this.searchCache.get(cacheKey);
        if (cached) return cached;

        const queryEmbedding = await this.embeddingModel.embed(query);
        // Retrieve 2x topK for ranking
        const results = await this.vectorStore.search(queryEmbedding, topK * 2, filter);
        const ranked = this.ranker.rank(results).slice(0, topK);
        
        this.searchCache.set(cacheKey, ranked, 60000); // 1 min cache
        return ranked;
    }
    
    clearCache(): void {
        this.searchCache.clear();
    }
}
