import { DocumentLoader } from './document_loader';
import { DocumentChunker } from './chunker';
import { VectorStore } from './vector_store';
import { EmbeddingModel } from './embeddings';
import { Retriever } from './retriever';
import { SearchResult } from './types';

export class KnowledgeManager {
    private docIds = new Set<string>();

    constructor(
        private documentLoader: DocumentLoader,
        private chunker: DocumentChunker,
        private embeddingModel: EmbeddingModel,
        private vectorStore: VectorStore,
        public retriever: Retriever
    ) {}

    async addDocument(filePath: string): Promise<string> {
        const doc = await this.documentLoader.load(filePath);
        const chunks = this.chunker.chunk(doc);
        
        const texts = chunks.map(c => c.text);
        const embeddings = await this.embeddingModel.embedBatch(texts);
        
        for (let i = 0; i < chunks.length; i++) {
            chunks[i].embedding = embeddings[i];
        }
        
        await this.vectorStore.insert(chunks);
        this.docIds.add(doc.id);
        
        // Invalidate cache when new data is added
        this.retriever.clearCache();
        
        return doc.id;
    }
    
    async removeDocument(docId: string): Promise<void> {
        // Find chunks by documentId isn't efficiently stored in InMemoryVectorStore unless we maintain a secondary index.
        // For production, VectorStore.delete would support metadata filtering. 
        // Here we assume vectorStore is handled externally or just don't fully implement remove for mock.
        this.docIds.delete(docId);
        this.retriever.clearCache();
    }
    
    async query(query: string, topK: number = 5): Promise<SearchResult[]> {
        return this.retriever.retrieve(query, topK);
    }
    
    getStats(): any {
        return {
            documentCount: this.docIds.size
        };
    }
}
