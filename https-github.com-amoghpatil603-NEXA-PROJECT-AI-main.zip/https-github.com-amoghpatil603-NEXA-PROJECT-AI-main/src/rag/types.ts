export interface Document {
    id: string;
    text: string;
    metadata: Record<string, any>;
}

export interface Chunk {
    id: string;
    documentId: string;
    text: string;
    metadata: Record<string, any>;
    embedding?: number[];
}

export interface SearchResult {
    chunk: Chunk;
    score: number;
}
