import { Chunk, SearchResult } from './types';

export interface VectorStore {
    insert(chunks: Chunk[]): Promise<void>;
    delete(chunkIds: string[]): Promise<void>;
    update(chunks: Chunk[]): Promise<void>;
    search(queryEmbedding: number[], topK: number, filter?: Record<string, any>): Promise<SearchResult[]>;
}

export class InMemoryVectorStore implements VectorStore {
    private chunks: Chunk[] = [];

    async insert(chunks: Chunk[]): Promise<void> {
        this.chunks.push(...chunks);
    }
    
    async delete(chunkIds: string[]): Promise<void> {
        const idSet = new Set(chunkIds);
        this.chunks = this.chunks.filter(c => !idSet.has(c.id));
    }
    
    async update(chunks: Chunk[]): Promise<void> {
        await this.delete(chunks.map(c => c.id));
        await this.insert(chunks);
    }
    
    private cosineSimilarity(v1: number[], v2: number[]): number {
        let dot = 0, norm1 = 0, norm2 = 0;
        for(let i=0; i<v1.length; i++) {
            dot += v1[i]*v2[i];
            norm1 += v1[i]*v1[i];
            norm2 += v2[i]*v2[i];
        }
        if (norm1 === 0 || norm2 === 0) return 0;
        return dot / (Math.sqrt(norm1)*Math.sqrt(norm2));
    }

    async search(queryEmbedding: number[], topK: number, filter?: Record<string, any>): Promise<SearchResult[]> {
        const results: SearchResult[] = [];
        for (const chunk of this.chunks) {
            if (!chunk.embedding) continue;
            let match = true;
            if (filter) {
                for (const key in filter) {
                    if (chunk.metadata[key] !== filter[key]) {
                        match = false;
                        break;
                    }
                }
            }
            if (match) {
                results.push({ chunk, score: this.cosineSimilarity(queryEmbedding, chunk.embedding) });
            }
        }
        results.sort((a, b) => b.score - a.score);
        return results.slice(0, topK);
    }
}
