import { SearchResult } from './types';

export interface RankingOptions {
    recencyBoost?: number;
    diversityBoost?: number;
}

export class Ranker {
    constructor(private options: RankingOptions = {}) {}

    rank(results: SearchResult[]): SearchResult[] {
        // Base sorting
        const ranked = [...results].sort((a, b) => b.score - a.score);
        
        // Optional recency boost
        if (this.options.recencyBoost) {
            const now = Date.now();
            ranked.forEach(r => {
                const ts = r.chunk.metadata.timestamp;
                if (ts) {
                    const age = now - ts;
                    const boost = Math.max(0, 1 - (age / (1000 * 60 * 60 * 24 * 365))); // scale of 1 year
                    r.score += boost * (this.options.recencyBoost ?? 0);
                }
            });
            ranked.sort((a, b) => b.score - a.score);
        }

        return ranked;
    }
}
